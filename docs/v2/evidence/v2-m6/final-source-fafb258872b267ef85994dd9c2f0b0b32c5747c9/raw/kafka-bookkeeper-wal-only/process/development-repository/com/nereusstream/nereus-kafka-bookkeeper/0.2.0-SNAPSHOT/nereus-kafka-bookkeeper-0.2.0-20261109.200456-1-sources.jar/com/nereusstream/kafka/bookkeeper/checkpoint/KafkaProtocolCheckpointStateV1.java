/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.kafka.bookkeeper.checkpoint;

import com.nereusstream.kafka.bookkeeper.commit.KafkaCommittedProducerStateV1;
import com.nereusstream.kafka.bookkeeper.commit.KafkaLeaderEpochIndexV1;
import com.nereusstream.kafka.bookkeeper.commit.KafkaTransactionStateV1;
import com.nereusstream.kafka.bookkeeper.nbke2.Nbke2ProtocolCheckpointV1;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/** Exact protocol components named by one compatible recovery vector. */
public record KafkaProtocolCheckpointStateV1(
        KafkaRecoveryCheckpointVectorV1 vector,
        KafkaCommittedProducerStateV1 producerState,
        KafkaTransactionStateV1 transactionState,
        KafkaLeaderEpochIndexV1 leaderEpochIndex,
        List<KafkaCheckpointReadIndexV1> readIndexes) {
    public KafkaProtocolCheckpointStateV1 {
        Objects.requireNonNull(vector, "vector");
        Objects.requireNonNull(producerState, "producerState");
        Objects.requireNonNull(transactionState, "transactionState");
        Objects.requireNonNull(leaderEpochIndex, "leaderEpochIndex");
        readIndexes = List.copyOf(readIndexes);
        var sourceIds = new HashSet<com.nereusstream.storage.api.bookkeeper.StorageRunId>();
        for (var source : readIndexes) {
            if (!sourceIds.add(source.runId())
                    || source.rows().get(source.rows().size() - 1).endOffsetExclusive()
                            > vector.recoveryCoveredThrough()) {
                throw new IllegalArgumentException("checkpoint sources repeat or escape common coverage");
            }
        }
        new KafkaProtocolCheckpointComponentsV1(producerState, transactionState, leaderEpochIndex)
                .requireCoverage(
                        vector.producerStateCoveredThrough(),
                        vector.transactionIndexCoveredThrough(),
                        vector.leaderEpochCoveredThrough());
    }

    public KafkaProtocolCheckpointStateV1(
            KafkaRecoveryCheckpointVectorV1 vector,
            KafkaCommittedProducerStateV1 producerState,
            KafkaTransactionStateV1 transactionState,
            KafkaLeaderEpochIndexV1 leaderEpochIndex) {
        this(vector, producerState, transactionState, leaderEpochIndex, List.of());
    }

    public static KafkaProtocolCheckpointStateV1 empty(
            com.nereusstream.kafka.bookkeeper.nbke2.Nbke2RunBindingV1 runBinding, long startOffset) {
        KafkaRecoveryCheckpointVectorV1 vector =
                new KafkaRecoveryCheckpointVectorV1(runBinding, startOffset, startOffset, startOffset, startOffset);
        return new KafkaProtocolCheckpointStateV1(
                vector,
                KafkaCommittedProducerStateV1.empty(),
                KafkaTransactionStateV1.empty(),
                KafkaLeaderEpochIndexV1.empty());
    }

    public Nbke2ProtocolCheckpointV1 toNbke2() {
        KafkaProtocolCheckpointSectionsV1 sections = KafkaProtocolCheckpointCodecV1.encode(this);
        return new Nbke2ProtocolCheckpointV1(
                vector.runBinding(),
                vector.rangeIndexCoveredThrough(),
                vector.producerStateCoveredThrough(),
                vector.transactionIndexCoveredThrough(),
                vector.leaderEpochCoveredThrough(),
                sections.producerState(),
                sections.transactionIndex(),
                sections.leaderEpochIndex());
    }

    public KafkaProtocolCheckpointComponentsV1 components() {
        return new KafkaProtocolCheckpointComponentsV1(producerState, transactionState, leaderEpochIndex);
    }

    public static KafkaProtocolCheckpointStateV1 fromNbke2(Nbke2ProtocolCheckpointV1 checkpoint) {
        Objects.requireNonNull(checkpoint, "checkpoint");
        return KafkaProtocolCheckpointCodecV1.decode(
                KafkaRecoveryCheckpointVectorV1.from(checkpoint),
                new KafkaProtocolCheckpointSectionsV1(
                        checkpoint.producerState(), checkpoint.transactionIndex(), checkpoint.leaderEpochIndex()));
    }
}
