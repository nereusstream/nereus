/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.storage.object.control;

import com.nereusstream.domain.bytes.CanonicalBytes;
import com.nereusstream.domain.bytes.Sha256Digest;
import com.nereusstream.domain.codec.ProtocolCellIdentityCodecV1;
import com.nereusstream.storage.api.bookkeeper.CellProviderScopeId;
import com.nereusstream.storage.object.kms.KmsCellSession;
import com.nereusstream.storage.object.kms.RunKeyCacheIdentity;
import com.nereusstream.storage.object.kms.WrappedRunKeyEnvelope;
import com.nereusstream.storage.object.nwg1.GroupEncodingPlanV1;
import com.nereusstream.storage.object.nwg1.Nwg1CommitmentsV1;
import com.nereusstream.storage.object.nwg1.Nwg1EnvelopeV1;
import com.nereusstream.storage.object.nwg1.Nwg1ObjectReaderV1;
import com.nereusstream.storage.object.nwg1.Nwg1RootAuthorityV1;
import com.nereusstream.storage.object.nwg1.Nwg1SealedObjectV1;
import com.nereusstream.storage.object.nwg1.Nwg1VerificationContextV1;
import com.nereusstream.storage.object.nwg1.Nwg1VerificationPathV1;
import com.nereusstream.storage.object.provider.C1ObjectProviderSession;
import com.nereusstream.storage.object.provider.ObjectIdentity;
import com.nereusstream.storage.object.provider.ProviderObjectOutcome;
import com.nereusstream.storage.object.provider.ProviderObjectResult;
import com.nereusstream.storage.object.provider.RepeatableObjectBody;
import com.nereusstream.storage.object.recovery.BoundedObjectTailRecovery;
import com.nereusstream.storage.object.recovery.CumulativeRecoveryBudget;
import com.nereusstream.storage.object.recovery.RecoveredWalRunRuntimeCut;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.LongSupplier;

/**
 * Root-bound production owner for admission, Provider/KMS Cell sessions, and one cumulative recovery envelope. It is
 * the only common API that hands plaintext run-key material to NWG1, and that handoff never crosses this class.
 */
public final class WalRunObjectSession implements AutoCloseable {
    public enum State {
        OPEN,
        DRAINING,
        CLOSED
    }

    private final WalRunRootRecord root;
    private final Sha256Digest rootSha256;
    private final WalRunRuntime runtime;
    private final C1ObjectProviderSession.WalRunLease provider;
    private final KmsCellSession.WalRunLease kms;
    private final RunKeyCacheIdentity runKeyIdentity;
    private final BoundedObjectTailRecovery recovery;
    private final RecoveredWalRunRuntimeCut recoveredCut;
    private final Nwg1RootAuthorityV1 nwg1RootAuthority;
    private final boolean recoveredCurrentRoot;
    private boolean recoveredRowsReleased;
    private WalCheckpointHeadV1 recoveredFinalHead;
    private RecoveredProtocolClosure recoveredProtocolClosure;
    private volatile State state = State.OPEN;
    private int activeIo;
    private final java.util.Set<WalCheckpointPublisher> checkpointPublishers = new java.util.HashSet<>();

    synchronized void attachCheckpointPublisher(WalCheckpointPublisher publisher) {
        requireUsable();
        checkpointPublishers.add(publisher);
    }

    void requireCheckpointAdmission() {
        requireOpen();
        if (runtime.state() != WalRunRuntime.State.ADMITTING) {
            throw new IllegalStateException("checkpoint admission requires an admitting physical run");
        }
    }

    /** Counts actual I/O lifetime; drain/interrupt cannot release the Provider/KMS leases underneath it. */
    public synchronized IoLease acquireTerminalIo() {
        requireTerminalClosable();
        return acquireIo();
    }

    /** Pins an original synchronous control read until its native stage has actually terminated. */
    public synchronized IoLease acquireControlReadIo() {
        return acquireIo();
    }

    /** Ordinary protocol mutations stop with physical admission; only sealed terminal CAS may finish later. */
    public synchronized IoLease acquireProtocolMutationIo(boolean terminal) {
        if (terminal) {
            requireTerminalClosable();
        } else {
            requireCheckpointAdmission();
        }
        return acquireIo();
    }

    /**
     * Allows one exact final Kafka checkpoint Object after recovered physical rows are checkpointed. No NWG1
     * sequence admission is restored. The caller holds the durable native recovery owner fence.
     */
    public synchronized RecoveredProtocolClosure prepareRecoveredProtocolClosure(
            WalCheckpointHeadV1 exactPhysicalHead, ObjectIdentity exactProtocolObject) {
        requireRecoveredCurrentRoot();
        requireOpen();
        requireKafkaProtocolIdentity(exactProtocolObject);
        if (runtime.state() != WalRunRuntime.State.STOPPING
                || !Objects.requireNonNull(exactPhysicalHead, "exactPhysicalHead")
                        .equals(recoveredFinalHead)) {
            throw new IllegalStateException("recovered Kafka checkpoint requires the final selected physical Head");
        }
        if (recoveredProtocolClosure == null) {
            recoveredProtocolClosure = new RecoveredProtocolClosure(exactProtocolObject);
        } else if (!recoveredProtocolClosure.object.equals(exactProtocolObject)) {
            throw new IllegalStateException("recovered protocol closure retains another exact candidate");
        }
        return recoveredProtocolClosure;
    }

    public static final class RecoveredProtocolClosure {
        private final ObjectIdentity object;

        private RecoveredProtocolClosure(ObjectIdentity object) {
            this.object = object;
        }
    }

    public synchronized IoLease acquireRecoveredProtocolMutationIo(RecoveredProtocolClosure closure) {
        requireRecoveredProtocolAdmission(closure);
        return acquireIo();
    }

    private void requireRecoveredProtocolAdmission(RecoveredProtocolClosure closure) {
        requireOpen();
        if (closure == null || closure != recoveredProtocolClosure || runtime.state() != WalRunRuntime.State.STOPPING) {
            throw new IllegalStateException("stale or foreign recovered Kafka checkpoint closure");
        }
    }

    synchronized IoLease acquireIo() {
        requireUsable();
        activeIo = Math.incrementExact(activeIo);
        return new IoLease(this, null);
    }

    private synchronized IoLease acquireCandidateIo(AdmittedNwg1Candidate candidate) {
        requireCandidate(candidate);
        if (candidate.ioInFlight) {
            throw new IllegalStateException("exact NWG1 candidate already has in-flight I/O");
        }
        candidate.ioInFlight = true;
        activeIo = Math.incrementExact(activeIo);
        return new IoLease(this, candidate);
    }

    public static final class IoLease implements AutoCloseable {
        private final WalRunObjectSession owner;
        private final AdmittedNwg1Candidate candidate;
        private boolean closed;

        private IoLease(WalRunObjectSession owner, AdmittedNwg1Candidate candidate) {
            this.owner = owner;
            this.candidate = candidate;
        }

        @Override
        public void close() {
            synchronized (owner) {
                if (!closed) {
                    closed = true;
                    owner.activeIo--;
                    if (candidate != null) {
                        candidate.ioInFlight = false;
                    }
                }
            }
        }
    }

    /** Package-local isolated-test constructor; production fresh opens require lifecycle owner authority. */
    WalRunObjectSession(
            WalRunRootRecord root, C1ObjectProviderSession provider, KmsCellSession kms, LongSupplier nanoTime) {
        this(
                root,
                new WalRunRuntime(root),
                provider,
                kms,
                BoundedObjectTailRecovery.prepareNewRoot(root, nanoTime),
                null,
                null,
                null);
    }

    /** Package-local isolated-test constructor; production fresh opens require lifecycle owner authority. */
    WalRunObjectSession(
            WalRunRootRecord root,
            WalRunRuntime runtime,
            C1ObjectProviderSession provider,
            KmsCellSession kms,
            LongSupplier nanoTime) {
        this(root, runtime, provider, kms, BoundedObjectTailRecovery.prepareNewRoot(root, nanoTime), null, null, null);
    }

    /** Fresh production open consumes an exact lifecycle-published Root authority once, after session readiness. */
    public static WalRunObjectSession openNew(
            WalRunLifecycleManager.NewWalRunOwnerAuthority ownerAuthority,
            C1ObjectProviderSession provider,
            KmsCellSession kms,
            LongSupplier nanoTime) {
        Objects.requireNonNull(ownerAuthority, "ownerAuthority");
        WalRunRootRecord root = ownerAuthority.requireConsumableRoot();
        return new WalRunObjectSession(
                root,
                new WalRunRuntime(root),
                provider,
                kms,
                BoundedObjectTailRecovery.prepareNewRoot(root, nanoTime),
                null,
                ownerAuthority,
                null);
    }

    /** Fresh production open transfers the exact pre-Root key reservation with the published owner authority. */
    public static WalRunObjectSession openNew(
            WalRunLifecycleManager.NewWalRunOwnerAuthority ownerAuthority,
            C1ObjectProviderSession provider,
            KmsCellSession.NewRunKeyCreation newRunKey,
            LongSupplier nanoTime) {
        Objects.requireNonNull(ownerAuthority, "ownerAuthority");
        Objects.requireNonNull(newRunKey, "newRunKey");
        WalRunRootRecord root = ownerAuthority.requireConsumableRoot();
        return new WalRunObjectSession(
                root,
                new WalRunRuntime(root),
                provider,
                null,
                BoundedObjectTailRecovery.prepareNewRoot(root, nanoTime),
                null,
                ownerAuthority,
                newRunKey);
    }

    private WalRunObjectSession(
            WalRunRootRecord root,
            WalRunRuntime runtime,
            C1ObjectProviderSession rawProvider,
            KmsCellSession kms,
            BoundedObjectTailRecovery.PreparedNewRootRecovery preparedNewRoot,
            RecoveredWalRunRuntimeCut recoveredCut,
            WalRunLifecycleManager.NewWalRunOwnerAuthority newOwnerAuthority,
            KmsCellSession.NewRunKeyCreation newRunKey) {
        this.root = Objects.requireNonNull(root, "root");
        this.root.requireM3ProductionProviderProofMode();
        this.rootSha256 = WalRunControlCodec.rootSha256(root);
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        C1ObjectProviderSession suppliedProvider =
                recoveredCut == null ? Objects.requireNonNull(rawProvider, "provider") : rawProvider;
        KmsCellSession suppliedKms =
                recoveredCut == null && newRunKey == null ? Objects.requireNonNull(kms, "kms") : kms;
        if (!runtime.rootRecord().equals(root)
                || (recoveredCut == null
                        && (!suppliedProvider.providerScopeId().equals(root.providerScopeId())
                                || !suppliedProvider
                                        .exclusiveNamespacePrefix()
                                        .equals(root.providerConfiguration().exclusiveNamespacePrefix())
                                || suppliedProvider.admittedMaximumObjectBytes()
                                        != root.providerConfiguration().maxObjectBodyBytes()
                                || suppliedProvider.admittedMaximumPrefixBytes()
                                        != root.nwg1AdmissionCaps().maxDirectoryPrefixBytes()
                                || !(newRunKey == null ? suppliedKms.providerScopeId() : newRunKey.providerScopeId())
                                        .equals(root.providerScopeId())))) {
            throw new IllegalArgumentException(
                    "WalRun authority differs: runtime/Provider/KMS Cell authorities differ from the Root");
        }
        this.runKeyIdentity = new RunKeyCacheIdentity(root.shardId(), root.shardRunEpoch());
        byte[] npc1 =
                ProtocolCellIdentityCodecV1.encode(root.protocolCellIdentity()).toByteArray();
        Nwg1EnvelopeV1 envelope =
                Nwg1EnvelopeV1.decode(root.wrappedRunKey().framedBytes().toByteArray());
        this.nwg1RootAuthority = new Nwg1RootAuthorityV1(
                npc1,
                Nwg1CommitmentsV1.protocolCell(npc1),
                root.providerScopeId().digest().bytes().toByteArray(),
                rootSha256.bytes().toByteArray(),
                root.wrappedRunKey().framedBytes().toByteArray(),
                Nwg1CommitmentsV1.wrappedEnvelope(envelope));
        if ((preparedNewRoot == null) == (recoveredCut == null)) {
            throw new IllegalArgumentException(
                    "WalRun session must be new-root or recovered-current-root exactly once");
        }
        if (newRunKey != null && (newOwnerAuthority == null || recoveredCut != null)) {
            throw new IllegalArgumentException("new run key creation requires a fresh published Root authority");
        }
        if (recoveredCut != null) {
            recoveredCut.requireConsumableFor(root);
        }
        ProviderOwnerAuthority providerAuthority = new ProviderOwnerAuthority(
                this,
                root.providerScopeId(),
                root.providerConfiguration().exclusiveNamespacePrefix(),
                root.providerConfiguration().maxObjectBodyBytes(),
                root.nwg1AdmissionCaps().maxDirectoryPrefixBytes());
        KmsOwnerAuthority kmsAuthority =
                new KmsOwnerAuthority(this, runKeyIdentity, root.wrappedRunKey(), rootSha256, root.providerScopeId());
        C1ObjectProviderSession.WalRunLease transferredProvider;
        KmsCellSession.WalRunLease transferredKms;
        BoundedObjectTailRecovery transferredRecovery;
        if (recoveredCut != null) {
            synchronized (recoveredCut) {
                recoveredCut.requireConsumableFor(root);
                var promoted = recoveredCut.promoteRecoveryLeases(root, providerAuthority, kmsAuthority);
                transferredProvider = promoted.provider();
                transferredKms = promoted.kms();
                transferredRecovery =
                        BoundedObjectTailRecovery.fromRecoveredRuntimeCut(transferredProvider, root, recoveredCut);
            }
        } else if (newOwnerAuthority != null) {
            synchronized (newOwnerAuthority) {
                newOwnerAuthority.requireConsumableRoot();
                synchronized (suppliedProvider) {
                    synchronized (newRunKey == null ? suppliedKms.lifecycleMonitor() : newRunKey.lifecycleMonitor()) {
                        suppliedProvider.requireTransferReady(providerAuthority);
                        if (newRunKey == null) {
                            suppliedKms.requireTransferReady(kmsAuthority);
                        } else {
                            newRunKey.requireRootCandidate(root);
                            newRunKey.requireTransferReady(kmsAuthority);
                        }
                        newOwnerAuthority.consumeFor(root);
                        transferredProvider = suppliedProvider.transferToWalRun(providerAuthority);
                        transferredKms = newRunKey == null
                                ? suppliedKms.transferToWalRun(kmsAuthority)
                                : newRunKey.transferToWalRun(kmsAuthority);
                        transferredRecovery = BoundedObjectTailRecovery.fromPreparedNewRoot(
                                transferredProvider, root, Objects.requireNonNull(preparedNewRoot, "preparedNewRoot"));
                    }
                }
            }
        } else {
            // This constructor path is package-visible solely for isolated common tests. Production callers cannot
            // name it and must use openNew(NewWalRunOwnerAuthority, ...).
            synchronized (suppliedProvider) {
                synchronized (suppliedKms.lifecycleMonitor()) {
                    suppliedProvider.requireTransferReady(providerAuthority);
                    suppliedKms.requireTransferReady(kmsAuthority);
                    transferredProvider = suppliedProvider.transferToWalRun(providerAuthority);
                    transferredKms = suppliedKms.transferToWalRun(kmsAuthority);
                    transferredRecovery = BoundedObjectTailRecovery.fromPreparedNewRoot(
                            transferredProvider, root, Objects.requireNonNull(preparedNewRoot, "preparedNewRoot"));
                }
            }
        }
        this.provider = transferredProvider;
        this.kms = transferredKms;
        this.recovery = transferredRecovery;
        this.recoveredCut = recoveredCut;
        this.recoveredCurrentRoot = recoveredCut != null;
    }

    public static WalRunObjectSession restore(WalRunRootRecord root, RecoveredWalRunRuntimeCut recoveredCut) {
        Objects.requireNonNull(recoveredCut, "recoveredCut");
        WalRunRuntime restoredRuntime = recoveredCut.restoreRuntimeFor(root);
        return new WalRunObjectSession(root, restoredRuntime, null, null, null, recoveredCut, null, null);
    }

    /** Performs the complete no-effect Root/format/cap/plan validation before a caller locks local rollback state. */
    public synchronized ValidatedNwg1Plan validateNwg1Plan(
            GroupEncodingPlanV1 plan, Nwg1VerificationContextV1 verificationContext) {
        requireOpen();
        Objects.requireNonNull(plan, "plan");
        requireVerificationContext(verificationContext);
        GroupEncodingPlanV1.AdmissionFacts facts = plan.requireAdmission(root.nwg1AdmissionCaps());
        if (plan.protocolKind() != root.protocolCellIdentity().protocolKind().code()
                || plan.shardId() != root.shardId()
                || plan.shardRunEpoch() != root.shardRunEpoch()
                || !Arrays.equals(plan.protocolCellCommitment(), nwg1RootAuthority.protocolCellCommitment())
                || !Arrays.equals(plan.providerScopeId(), nwg1RootAuthority.cellProviderScopeId())
                || !Arrays.equals(plan.rootSha256(), rootSha256.bytes().toByteArray())
                || !Arrays.equals(plan.envelopeCommitment(), nwg1RootAuthority.wrappedEnvelopeCommitment())) {
            throw new IllegalArgumentException("NWG1 plan substituted the exact WalRun Root authority");
        }
        plan.requireSemanticAdmission(verificationContext);
        Sha256Digest planSha256 = plan.canonicalPlanSha256();
        ImmutableExtentPlan immutablePlan = new ImmutableExtentPlan(
                WalLaneId.fromCode(plan.laneId()), plan.packingPolicyVersion(), planSha256, facts.canonicalBodyBytes());
        return new ValidatedNwg1Plan(this, plan, verificationContext, immutablePlan, facts);
    }

    public ProviderObjectResult conditionalCreateNwg1(AdmittedNwg1Candidate candidate) throws IOException {
        IoLease lease;
        synchronized (this) {
            requireOpen();
            lease = acquireCandidateIo(candidate);
            try {
                chargeConditionalCreateAttempt(candidate.conditionalCreateAttempts);
                candidate.conditionalCreateAttempts = Math.incrementExact(candidate.conditionalCreateAttempts);
                candidate.persistenceResult = ProviderObjectResult.outcome(ProviderObjectOutcome.OUTCOME_UNKNOWN);
            } catch (RuntimeException failure) {
                lease.close();
                throw failure;
            }
        }
        try (lease) {
            var result = provider.conditionalCreate(candidate.uploadBody);
            synchronized (this) {
                requireCandidate(candidate);
                candidate.persistenceResult = result;
            }
            return result;
        }
    }

    /** Creates a Root-bound Kafka NWKCP1 token only after exact content-key/body validation. */
    public synchronized ValidatedKafkaProtocolObject validateKafkaProtocolObject(
            ObjectIdentity identity, CanonicalBytes canonicalBody) {
        requireUsable();
        requireKafkaProtocolIdentity(identity);
        Objects.requireNonNull(canonicalBody, "canonicalBody");
        if (canonicalBody.length() != identity.bodyLength()
                || !Sha256Digest.hash(canonicalBody).equals(identity.bodySha256())) {
            throw new IllegalArgumentException("Kafka protocol Object body differs from its content identity");
        }
        return new ValidatedKafkaProtocolObject(this, identity, canonicalBody);
    }

    public ProviderObjectResult conditionalCreateKafkaProtocolObject(ValidatedKafkaProtocolObject candidate)
            throws IOException {
        return conditionalCreateKafkaProtocolObject(candidate, null);
    }

    public ProviderObjectResult conditionalCreateKafkaProtocolObject(
            ValidatedKafkaProtocolObject candidate, RecoveredProtocolClosure closure) throws IOException {
        IoLease lease;
        synchronized (this) {
            Objects.requireNonNull(candidate, "candidate");
            if (closure == null) {
                requireCheckpointAdmission();
            } else {
                requireRecoveredProtocolAdmission(closure);
                if (!closure.object.equals(candidate.identity)) {
                    throw new IllegalArgumentException("recovered Kafka checkpoint differs from its exact candidate");
                }
            }
            if (candidate.owner != this) {
                throw new IllegalArgumentException("Kafka protocol Object token belongs to another WalRun session");
            }
            if (candidate.ioInFlight) {
                throw new IllegalStateException("Kafka protocol Object token already has in-flight I/O");
            }
            chargeConditionalCreateAttempt(candidate.conditionalCreateAttempts);
            candidate.conditionalCreateAttempts = Math.incrementExact(candidate.conditionalCreateAttempts);
            lease = acquireIo();
            candidate.ioInFlight = true;
        }
        try (lease) {
            return provider.conditionalCreate(new CanonicalCandidateBody(candidate.identity, candidate.body));
        } finally {
            synchronized (this) {
                candidate.ioInFlight = false;
            }
        }
    }

    /** Projects the sole Root-authorized full Object identity from a sealed NWG1 relative leaf and body. */
    public synchronized ObjectIdentity requireNwg1Identity(Nwg1SealedObjectV1 sealed) {
        requireUsable();
        Objects.requireNonNull(sealed, "sealed");
        ObjectWalLeafKeyV1 leaf = ObjectWalLeafKeyV1.parseRelative(sealed.leafUtf8());
        Sha256Digest bodySha = Sha256Digest.copyOf(sealed.bodySha256());
        if (leaf.bodyLength() != sealed.bodyLength()
                || leaf.directoryPrefixEnd() != sealed.header().directoryPrefixEnd()
                || !leaf.objectSha256().equals(bodySha)) {
            throw new IllegalArgumentException("sealed NWG1 leaf differs from its exact Header/body identity");
        }
        return new ObjectIdentity(leaf.fullKey(root.providerConfiguration()), leaf.bodyLength(), bodySha);
    }

    /**
     * The sole production sequence/seal cut. Validation has no sequence effect; any exception from this method
     * reports whether the exact pending reservation now exists and must be retained for same-plan retry.
     */
    public AdmittedNwg1Candidate admitAndSealNwg1(ValidatedNwg1Plan validatedPlan, long nowMillis) {
        Objects.requireNonNull(validatedPlan, "validatedPlan");
        LaneSequenceReservation reservation;
        IoLease lease;
        synchronized (this) {
            if (validatedPlan.owner != this) {
                throw new Nwg1AdmissionFailure(
                        Optional.empty(),
                        validatedPlan.immutablePlan.canonicalPlanSha256(),
                        new IllegalArgumentException("validated NWG1 plan belongs to another WalRun session"));
            }
            requireUsable();
            if (validatedPlan.candidate != null) {
                if (validatedPlan.candidate.terminal) {
                    throw new Nwg1AdmissionFailure(
                            Optional.of(validatedPlan.candidate.reservation),
                            validatedPlan.immutablePlan.canonicalPlanSha256(),
                            new IllegalStateException("validated NWG1 candidate is already terminal"));
                }
                return validatedPlan.candidate;
            }
            if (validatedPlan.sealing) {
                throw new Nwg1AdmissionFailure(
                        Optional.ofNullable(validatedPlan.reservation),
                        validatedPlan.immutablePlan.canonicalPlanSha256(),
                        new IllegalStateException("NWG1 seal already has in-flight I/O"));
            }
            try {
                reservation = runtime.admitOrRetrySealedPlan(validatedPlan.immutablePlan, nowMillis);
                if (validatedPlan.reservation != null && !validatedPlan.reservation.equals(reservation)) {
                    throw new IllegalStateException("validated NWG1 retry resolved to a different lane reservation");
                }
                validatedPlan.reservation = reservation;
                lease = acquireIo();
                validatedPlan.sealing = true;
            } catch (RuntimeException failure) {
                throw new Nwg1AdmissionFailure(
                        Optional.ofNullable(validatedPlan.reservation),
                        validatedPlan.immutablePlan.canonicalPlanSha256(),
                        failure);
            }
        }
        try (lease) {
            var sealed =
                    kms.sealNwg1(validatedPlan.plan, reservation.laneSequence(), validatedPlan.verificationContext);
            if (sealed.bodyLength() != validatedPlan.facts.canonicalBodyBytes()) {
                throw new IllegalStateException("sealed NWG1 body differs from the pre-sequence admission facts");
            }
            synchronized (this) {
                if (!reservation.equals(validatedPlan.reservation)) {
                    throw new IllegalStateException("NWG1 seal completion substituted the reserved candidate");
                }
                var candidate = new AdmittedNwg1Candidate(
                        this, validatedPlan, reservation, sealed, requireNwg1Identity(sealed));
                validatedPlan.candidate = candidate;
                return candidate;
            }
        } catch (RuntimeException failure) {
            throw new Nwg1AdmissionFailure(
                    Optional.of(reservation), validatedPlan.immutablePlan.canonicalPlanSha256(), failure);
        } finally {
            synchronized (this) {
                validatedPlan.sealing = false;
            }
        }
    }

    public synchronized void providerResolved(AdmittedNwg1Candidate candidate) {
        requireCandidate(candidate);
        requireCandidateIdle(candidate);
        runtime.providerResolved(candidate.reservation, candidate.identity.bodyLength());
        candidate.terminal = true;
    }

    public synchronized void providerAbsent(AdmittedNwg1Candidate candidate) {
        requireCandidate(candidate);
        requireCandidateIdle(candidate);
        runtime.providerAbsent(candidate.reservation);
        candidate.terminal = true;
    }

    public synchronized void providerConflict(AdmittedNwg1Candidate candidate) {
        requireCandidate(candidate);
        requireCandidateIdle(candidate);
        runtime.providerConflict(candidate.reservation);
        candidate.terminal = true;
    }

    public synchronized void stopAdmission(WalRunRuntime.StopReason reason) {
        requireUsable();
        runtime.stopAdmission(reason);
    }

    public synchronized LaneSequenceVector sealRuntime() {
        requireUsable();
        return runtime.seal();
    }

    synchronized void requireRecoveredClosureHead(WalCheckpointHeadV1 expected) {
        requireRecoveredCurrentRoot();
        if (runtime.state() != WalRunRuntime.State.STOPPING
                || recoveredRowsReleased
                || !recoveredCut.physicalHead().equals(expected)) {
            throw new IllegalStateException("physical checkpoint closure requires the unconsumed authenticated cut");
        }
    }

    /**
     * Fences the previous publisher and checkpoints every already authenticated recovered extent. The caller must
     * keep the native owner exclusion until the selected Head has been sealed; no sequence can be allocated here.
     */
    public synchronized WalCheckpointHeadV1 checkpointRecoveredPhysicalRows(
            CanonicalControlMetadataStore metadata, long publisherEpoch) throws IOException {
        requireRecoveredCurrentRoot();
        var before = recoveredCut.physicalHead();
        requireRecoveredClosureHead(before);
        recovery.chargeControlMetadata(1024 * 1024);
        var existingSeal = metadata.get(WalRunControlKeys.sealKey(root.shardId(), root.shardRunEpoch()));
        if (existingSeal.isPresent()) {
            return retainSealedRecoveredHead(before, WalRunControlCodec.decodeSeal(existingSeal.orElseThrow()));
        }
        try (var publisher = WalCheckpointPublisher.forRecoveredClosure(metadata, this, before)) {
            if (publisherEpoch > before.publisherEpoch()) {
                publisher.takeover(publisherEpoch);
            }
            if (publisher.head().publisherEpoch() != publisherEpoch) {
                throw new IllegalStateException("recovered physical publisher epoch was not selected");
            }
            var policy = root.checkpointPolicy();
            consumeRecoveredPhysicalRows(row -> {
                if (row.laneSequence() <= publisher.head().coveredThrough().get(row.laneId())) {
                    return;
                }
                if (publisher.uncoveredExtentCount()
                                >= Math.min(policy.maxUncheckpointedExtents(), policy.maxRowsPerPage())
                        || row.bodyLength() > policy.maxUncheckpointedBytes() - publisher.uncoveredBodyBytes()) {
                    publisher.flush();
                }
                publisher.enqueue(new ProviderResolvedExtentDescriptor(rootSha256, row, root.openedAtMillis()));
            });
            publisher.flush();
            publisher.requireFinalCoverage(runtime.resolvedVector());
            recoveredFinalHead = publisher.head();
            return recoveredFinalHead;
        }
    }

    private WalCheckpointHeadV1 retainSealedRecoveredHead(WalCheckpointHeadV1 before, WalRunSealRecord seal)
            throws IOException {
        if (!seal.root().rootSha256().equals(rootSha256)
                || !seal.finalCheckpointHeadKey().equals(recoveredCut.physicalHeadKey())
                || !seal.finalCheckpointHeadSha256().equals(recoveredCut.physicalHeadSha256())
                || !seal.terminalSequence().equals(runtime.resolvedVector())
                || seal.aggregateExtentCount() != runtime.resolvedExtentCount()
                || seal.aggregateCanonicalBodyBytes() != runtime.resolvedCanonicalBodyBytes()) {
            throw new IllegalStateException("existing Seal differs from the authenticated recovered physical cut");
        }
        consumeRecoveredPhysicalRows(ignored -> {});
        recoveredFinalHead = before;
        return recoveredFinalHead;
    }

    /** Closes the exact recovered vector only after all actual checkpoint and protocol work has ended. */
    public synchronized WalRunTerminalClosureProofV1 sealRecovered(
            WalRunLifecycleManager lifecycle, WalCheckpointHeadV1 finalHead) {
        requireRecoveredCurrentRoot();
        if (!Objects.requireNonNull(finalHead, "finalHead").equals(recoveredFinalHead)
                || !finalHead.rootSha256().equals(rootSha256)
                || finalHead.shardRunEpoch() != root.shardRunEpoch()
                || !finalHead.coveredThrough().equals(runtime.resolvedVector())) {
            throw new IllegalStateException("physical Seal differs from the exact checkpointed recovered vector");
        }
        sealRuntime();
        drain();
        requireTerminalClosable();
        var reference = new WalRunReference(
                WalRunControlKeys.rootKey(root.shardId(), root.shardRunEpoch()),
                rootSha256,
                root.shardId(),
                root.shardRunEpoch());
        var seal = new WalRunSealRecord(
                reference,
                finalHead.coveredThrough(),
                WalRunControlKeys.checkpointHeadKey(root.shardId(), root.shardRunEpoch()),
                Sha256Digest.hash(WalRunControlCodec.encodeCheckpointHead(finalHead)),
                runtime.resolvedExtentCount(),
                runtime.resolvedCanonicalBodyBytes());
        return lifecycle.publishSeal(WalRunControlKeys.sealKey(root.shardId(), root.shardRunEpoch()), seal, this);
    }

    public synchronized WalRunRuntime.State runtimeState() {
        requireUsable();
        return runtime.state();
    }

    public synchronized WalRunRuntime.RecoveredState runtimeRecoveryState() {
        requireUsable();
        return runtime.recoveryState();
    }

    synchronized void requireExactSealedClosure(WalRunRootRecord expectedRoot, WalRunSealRecord seal) {
        requireUsable();
        Objects.requireNonNull(expectedRoot, "expectedRoot");
        Objects.requireNonNull(seal, "seal");
        if (!root.equals(expectedRoot)
                || runtime.state() != WalRunRuntime.State.SEALED
                || !runtime.resolvedVector().equals(seal.terminalSequence())
                || runtime.resolvedExtentCount() != seal.aggregateExtentCount()
                || runtime.resolvedCanonicalBodyBytes() != seal.aggregateCanonicalBodyBytes()) {
            throw new IllegalStateException("physical Seal differs from the exact WalRun Object session closure");
        }
    }

    /**
     * Side-effect-free preflight required before publishing an immutable physical Seal. No accepted or unknown C1
     * operation may survive the cut, and the Root-bound KMS lease must remain available until publication finishes.
     */
    public synchronized void requireTerminalClosable() {
        if (state != State.DRAINING
                || activeIo != 0
                || runtime.state() != WalRunRuntime.State.SEALED
                || provider.acceptedOperations() != 0
                || provider.unknownObjectCount() != 0
                || kms.state() != KmsCellSession.State.OPEN) {
            throw new IllegalStateException(
                    "WalRun Object session is not a drained, sealed, Provider-clean, KMS-live terminal cut");
        }
    }

    /** Full GET and strict NWG1 verification share the Root cumulative recovery budget and KMS cache lifecycle. */
    public Nwg1ObjectReaderV1.DecodedObject readAndVerifyNwg1(
            ObjectIdentity identity,
            Nwg1VerificationPathV1 path,
            Nwg1VerificationContextV1 verificationContext,
            long selectedFrameOrdinal)
            throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireVerificationContext(verificationContext);
            return switch (path) {
                case ROUTINE_RANGE_READ ->
                    throw new IllegalArgumentException(
                            "routine selected-unit reads require the streaming frame-consumer API");
                case OPEN_RUN_RECOVERY -> {
                    Nwg1ObjectReaderV1.AuthenticatedPrefix prefix =
                            recoverAndVerifyNwg1Directory(identity, verificationContext);
                    yield new Nwg1ObjectReaderV1.DecodedObject(prefix.header(), prefix.directory(), List.of());
                }
                case FULL_BODY_RECONCILIATION -> {
                    ObjectWalLeafKeyV1 leaf = requireNwg1LeafIdentity(identity);
                    CanonicalBytes body = recovery.readVerifiedExtent(identity);
                    yield kms.verifyNwg1(
                            path,
                            nwg1RootAuthority,
                            verificationContext,
                            leaf.relativeKey().getBytes(StandardCharsets.US_ASCII),
                            body,
                            selectedFrameOrdinal);
                }
            };
        }
    }

    /**
     * Uses exact session-issued persistence evidence or performs a full GET/SHA proof, then authenticates structure.
     * The typed token rechecks current member-local Binding/native policy and independently consumes payloads.
     * Static wire facts come from the complete writer check or the existing authenticated streaming reader;
     * one member's failure cannot quarantine a valid sibling and no second Provider read is required.
     */
    public AuthenticatedNwg1PublicationExtent readAndAuthenticateNwg1ForPublication(
            AdmittedNwg1Candidate candidate, Nwg1VerificationContextV1 verificationContext) throws IOException {
        try (var lease = acquireCandidateIo(candidate)) {
            requireCandidate(candidate);
            requireVerificationContext(verificationContext);
            ObjectWalLeafKeyV1 leaf = requireNwg1LeafIdentity(candidate.identity);
            var selfChecked = candidate.sealed.selfCheckedPrefix(verificationContext);
            if (selfChecked.isPresent()
                    && candidate.persistenceResult != null
                    && provider.hasExactPersistenceEvidence(candidate.persistenceResult, candidate.uploadBody)) {
                var prefix = selfChecked.orElseThrow();
                requirePrefixIdentity(prefix, leaf);
                requirePrefixWithinRootCaps(prefix);
                return new AuthenticatedNwg1PublicationExtent(
                        this,
                        candidate,
                        prefix,
                        null,
                        requireProviderProof(candidate.persistenceResult.versionToken()));
            }
            var verifiedRead = provider.readVerifiedObjectWithVersion(candidate.identity);
            if (selfChecked.isPresent()) {
                var prefix = selfChecked.orElseThrow();
                requirePrefixIdentity(prefix, leaf);
                requirePrefixWithinRootCaps(prefix);
                return new AuthenticatedNwg1PublicationExtent(
                        this, candidate, prefix, null, requireProviderProof(verifiedRead.immutableVersionToken()));
            }
            byte[] exactBody = verifiedRead.canonicalBody().toByteArray();
            byte[] exactPrefix = Arrays.copyOfRange(exactBody, 0, Math.toIntExact(leaf.directoryPrefixEnd()));
            Nwg1ObjectReaderV1.AuthenticatedPrefix prefix =
                    kms.readAuthenticatedPrefix(exactPrefix, candidate.identity.bodyLength(), verificationContext);
            requirePrefixIdentity(prefix, leaf);
            requirePrefixWithinRootCaps(prefix);
            return new AuthenticatedNwg1PublicationExtent(
                    this, candidate, prefix, exactBody, requireProviderProof(verifiedRead.immutableVersionToken()));
        }
    }

    /** Verifies one member-selected append unit from the authenticated publication body with zero Provider I/O. */
    public synchronized Nwg1ObjectReaderV1.VerifiedAppendUnit verifySelectedNwg1AppendUnitForPublication(
            AuthenticatedNwg1PublicationExtent extent,
            Nwg1VerificationContextV1 verificationContext,
            long selectedFrameOrdinal,
            Nwg1ObjectReaderV1.VerifiedFrameConsumer consumer)
            throws IOException {
        requireUsable();
        Objects.requireNonNull(extent, "extent");
        if (extent.owner != this) {
            throw new IllegalArgumentException("publication extent token belongs to another WalRun session");
        }
        requireCandidate(extent.candidate);
        requireVerificationContext(verificationContext);
        if (extent.exactBody == null) {
            return Nwg1ObjectReaderV1.readSelfCheckedAppendUnit(
                    extent.candidate.sealed,
                    selectedFrameOrdinal,
                    verificationContext,
                    Objects.requireNonNull(consumer, "consumer"));
        }
        return kms.readSelectedAppendUnitStreaming(
                extent.prefix,
                bufferedNwg1Frames(extent.exactBody),
                selectedFrameOrdinal,
                verificationContext,
                Objects.requireNonNull(consumer, "consumer"));
    }

    /** Two-stage C1 prefix + exact selected append-unit frame ranges; no full GET and no recovery-budget charge. */
    public VerifiedRoutineNwg1AppendUnit readRoutineNwg1AppendUnit(
            ObjectIdentity identity,
            Nwg1VerificationContextV1 verificationContext,
            long selectedFrameOrdinal,
            Nwg1ObjectReaderV1.VerifiedFrameConsumer consumer)
            throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireVerificationContext(verificationContext);
            ObjectWalLeafKeyV1 leaf = requireNwg1LeafIdentity(identity);
            CanonicalBytes prefixBytes =
                    provider.readDirectoryPrefix(identity, leaf.directoryPrefixEnd(), Optional.empty());
            Nwg1ObjectReaderV1.AuthenticatedPrefix prefix =
                    kms.readAuthenticatedPrefix(prefixBytes.toByteArray(), identity.bodyLength(), verificationContext);
            requirePrefixIdentity(prefix, leaf);
            requirePrefixWithinRootCaps(prefix);
            Nwg1ObjectReaderV1.VerifiedAppendUnit appendUnit = kms.readSelectedAppendUnitStreaming(
                    prefix,
                    (range, ignored) -> provider.readExactRange(
                                    identity, range.inclusiveStart(), range.exclusiveEnd(), Optional.empty())
                            .toByteArray(),
                    selectedFrameOrdinal,
                    verificationContext,
                    Objects.requireNonNull(consumer, "consumer"));
            return new VerifiedRoutineNwg1AppendUnit(prefix, appendUnit);
        }
    }

    /** Authenticates the exact full body staged by the caller for materialization from this sealed Run. */
    public Nwg1ObjectReaderV1.VerifiedAppendUnit captureSealedNwg1AppendUnit(
            ObjectIdentity identity,
            CanonicalBytes canonicalBody,
            Nwg1VerificationContextV1 verification,
            long selectedFrameOrdinal,
            Nwg1ObjectReaderV1.VerifiedFrameConsumer consumer)
            throws IOException {
        Objects.requireNonNull(consumer, "consumer");
        try (var lease = acquireIo()) {
            if (runtime.state() != WalRunRuntime.State.SEALED) {
                throw new IllegalStateException("materialization requires a sealed WalRun");
            }
            requireVerificationContext(verification);
            var leaf = requireNwg1LeafIdentity(identity);
            byte[] body = requireMaterializationBody(identity, canonicalBody);
            var prefix = kms.readAuthenticatedPrefix(
                    Arrays.copyOfRange(body, 0, leaf.directoryPrefixEnd()), identity.bodyLength(), verification);
            requirePrefixIdentity(prefix, leaf);
            requirePrefixWithinRootCaps(prefix);
            return kms.readSelectedAppendUnitStreaming(
                    prefix, bufferedNwg1Frames(body), selectedFrameOrdinal, verification, consumer);
        }
    }

    static Nwg1ObjectReaderV1.ExactFrameSource bufferedNwg1Frames(byte[] exactBody) {
        return (range, ignored) -> Arrays.copyOfRange(
                exactBody, Math.toIntExact(range.inclusiveStart()), Math.toIntExact(range.exclusiveEnd()));
    }

    static byte[] requireMaterializationBody(ObjectIdentity identity, CanonicalBytes canonicalBody) throws IOException {
        if (canonicalBody.length() != identity.bodyLength()
                || !Sha256Digest.hash(canonicalBody).equals(identity.bodySha256())) {
            throw new IOException("materialization body differs from the exact Object identity");
        }
        return canonicalBody.toByteArray();
    }

    /** Authenticated transfer reads use the retiring Root's existing envelope, including cross-Run suffixes. */
    public VerifiedRoutineNwg1AppendUnit readNwg1AppendUnitForTransfer(
            ObjectIdentity identity,
            Nwg1VerificationContextV1 verificationContext,
            long selectedFrameOrdinal,
            Nwg1ObjectReaderV1.VerifiedFrameConsumer consumer,
            WalRunObjectSession budgetOwner)
            throws IOException {
        Objects.requireNonNull(budgetOwner, "budgetOwner");
        try (var sourceIo = acquireIo();
                var budgetIo = budgetOwner.acquireControlReadIo()) {
            requireVerificationContext(verificationContext);
            var leaf = requireNwg1LeafIdentity(identity);
            var reader = recovery.usingBudgetOf(budgetOwner.recovery);
            try (var memory =
                    budgetOwner.acquireRecoveryWorkingSet(Math.multiplyExact(3L, leaf.directoryPrefixEnd()))) {
                var raw = reader.reconstructDirectoryPrefixes(Map.of(identity, leaf.directoryPrefixEnd()))
                        .get(identity);
                var prefix = kms.readAuthenticatedPrefix(raw.toByteArray(), identity.bodyLength(), verificationContext);
                requirePrefixIdentity(prefix, leaf);
                requirePrefixWithinRootCaps(prefix);
                var directory = prefix.directory();
                reader.chargeDecoded(
                        directory.bindings().size(),
                        directory.frames().size(),
                        directory.appendUnits().size());
                var unit = directory.appendUnits().stream()
                        .filter(value -> value.firstFrameOrdinal() == selectedFrameOrdinal)
                        .findFirst()
                        .orElseThrow(() -> new IllegalArgumentException("transfer selected no exact append unit"));
                long maximumFrame = directory
                        .frames()
                        .subList(
                                Math.toIntExact(unit.firstFrameOrdinal()),
                                Math.toIntExact(unit.firstFrameOrdinal() + unit.frameCount()))
                        .stream()
                        .mapToLong(frame -> Math.addExact(frame.storedBlockBytes(), frame.decodedPayloadBytes()))
                        .max()
                        .orElseThrow();
                memory.grow(Math.multiplyExact(3L, maximumFrame));
                var verified = kms.readSelectedAppendUnitStreaming(
                        prefix,
                        (range, ignored) -> reader.readExactFrameRange(
                                        identity, range.inclusiveStart(), range.exclusiveEnd())
                                .toByteArray(),
                        selectedFrameOrdinal,
                        verificationContext,
                        Objects.requireNonNull(consumer, "consumer"));
                return new VerifiedRoutineNwg1AppendUnit(prefix, verified);
            }
        }
    }

    /** One cumulative range-GET authenticates the complete Directory needed to rebuild exact recovery locators. */
    public Nwg1ObjectReaderV1.AuthenticatedPrefix recoverAndVerifyNwg1Directory(
            ObjectIdentity identity, Nwg1VerificationContextV1 verificationContext) throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireVerificationContext(verificationContext);
            ObjectWalLeafKeyV1 leaf = requireNwg1LeafIdentity(identity);
            CanonicalBytes prefixBytes = recovery.reconstructDirectoryPrefixes(
                            Map.of(identity, leaf.directoryPrefixEnd()))
                    .get(identity);
            Nwg1ObjectReaderV1.AuthenticatedPrefix prefix =
                    kms.readAuthenticatedPrefix(prefixBytes.toByteArray(), identity.bodyLength(), verificationContext);
            requirePrefixIdentity(prefix, leaf);
            requirePrefixWithinRootCaps(prefix);
            recovery.chargeDecoded(
                    prefix.directory().bindings().size(),
                    prefix.directory().frames().size(),
                    prefix.directory().appendUnits().size());
            return prefix;
        }
    }

    /** Uses a previously authenticated recovery prefix and charges only its selected append-unit frame ranges. */
    public Nwg1ObjectReaderV1.VerifiedAppendUnit recoverAndVerifyNwg1AppendUnit(
            ObjectIdentity identity,
            Nwg1ObjectReaderV1.AuthenticatedPrefix prefix,
            Nwg1VerificationContextV1 verificationContext,
            long selectedFrameOrdinal,
            Nwg1ObjectReaderV1.VerifiedFrameConsumer consumer)
            throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireVerificationContext(verificationContext);
            ObjectWalLeafKeyV1 leaf = requireNwg1LeafIdentity(identity);
            requirePrefixIdentity(prefix, leaf);
            requirePrefixWithinRootCaps(prefix);
            return kms.readSelectedAppendUnitStreaming(
                    prefix,
                    (range, ignored) -> recovery.readExactFrameRange(
                                    identity, range.inclusiveStart(), range.exclusiveEnd())
                            .toByteArray(),
                    selectedFrameOrdinal,
                    verificationContext,
                    Objects.requireNonNull(consumer, "consumer"));
        }
    }

    public ProviderObjectResult reconcileUnknownExtent(ObjectIdentity identity) throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            return recovery.reconcileUnknownExtent(identity);
        }
    }

    /** Retains the exact full-GET reconciliation proof on this same immutable candidate. */
    public ProviderObjectResult reconcileUnknownNwg1Candidate(AdmittedNwg1Candidate candidate) throws IOException {
        try (var lease = acquireCandidateIo(candidate)) {
            requireCandidate(candidate);
            candidate.persistenceResult = ProviderObjectResult.outcome(ProviderObjectOutcome.OUTCOME_UNKNOWN);
            candidate.persistenceResult = recovery.reconcileUnknownExtent(candidate.identity);
            return candidate.persistenceResult;
        }
    }

    /** Resolves one live writer's exact original Object with bounded work independent of cold recovery time. */
    public ProviderObjectResult reconcileLiveNwg1Candidate(AdmittedNwg1Candidate candidate) throws IOException {
        try (var lease = acquireCandidateIo(candidate)) {
            requireCandidate(candidate);
            var persistence = candidate.persistenceResult;
            if (persistence == null) {
                throw new IllegalStateException("Live reconciliation requires an original conditional create");
            }
            if (persistence.outcome() != ProviderObjectOutcome.OUTCOME_UNKNOWN) {
                return persistence;
            }
            if (candidate.liveReconciliations >= 2) {
                throw new IllegalStateException("Exact live Object reconciliation has exhausted its attempts");
            }
            candidate.liveReconciliations++;
            var identity = candidate.identity;
            int keyBytes = identity.key().getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
            // Only this full content-addressed key can resolve the original dispatch. The Provider verifies the
            // complete body, and its transport still decides whether a negative observation is terminal.
            candidate.persistenceResult = provider.reconcileUnknown(identity, identity.key(), 1, 1, keyBytes, keyBytes)
                    .objectResult();
            return candidate.persistenceResult;
        }
    }

    /** Authenticated routine prefix plus the compact selected-unit fold; it never retains decoded frame bytes. */
    public record VerifiedRoutineNwg1AppendUnit(
            Nwg1ObjectReaderV1.AuthenticatedPrefix authenticatedPrefix,
            Nwg1ObjectReaderV1.VerifiedAppendUnit appendUnit) {
        public VerifiedRoutineNwg1AppendUnit {
            Objects.requireNonNull(authenticatedPrefix, "authenticatedPrefix");
            Objects.requireNonNull(appendUnit, "appendUnit");
        }
    }

    /** Complete streaming lane discovery is available only to a lineage-restored current-Root owner. */
    public synchronized BoundedObjectTailRecovery.RecoveredLaneFold discoverUncoveredLaneStreaming(
            WalLaneId laneId, BoundedObjectTailRecovery.RecoveredExtentConsumer recoveredExtentConsumer)
            throws IOException {
        requireRecoveredCurrentRoot();
        return recovery.discoverUncoveredLaneStreaming(laneId, recoveredExtentConsumer);
    }

    /** One-use complete physical inventory already authenticated and protocol-staged inside the durable fence. */
    public synchronized RecoveredWalRunRuntimeCut.PhysicalRowsSummary consumeRecoveredPhysicalRows(
            RecoveredWalRunRuntimeCut.PhysicalRowConsumer consumer) throws IOException {
        requireRecoveredCurrentRoot();
        if (activeIo != 0) {
            throw new IllegalStateException("recovered physical rows retain concurrent I/O; drain before consuming");
        }
        try {
            return Objects.requireNonNull(recoveredCut, "recoveredCut").consumeAuthenticatedPhysicalRows(consumer);
        } finally {
            if (!recoveredRowsReleased) {
                recovery.finishRecoveredPhysicalRows();
                recoveredRowsReleased = true;
            }
        }
    }

    public ProviderObjectResult reconcileUnknownProtocolObject(ObjectIdentity identity) throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireKafkaProtocolIdentity(identity);
            return recovery.reconcileUnknownProtocolObject(identity);
        }
    }

    public CanonicalBytes readVerifiedProtocolObject(ObjectIdentity identity) throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireKafkaProtocolIdentity(identity);
            return recovery.readVerifiedProtocolCheckpoint(identity);
        }
    }

    /**
     * Returns the predecessor-Root exact-read capability for a terminal-lineage verifier. The verifier's supplied
     * recovery context, not this session, precharges the one current-pointer budget; this capability therefore
     * must
     * not be used for ordinary tail recovery.
     */
    public synchronized TerminalProtocolCheckpointVerifierV1.ProtocolObjectRecoveryReaderV1
            terminalLineageProtocolObjectReader() {
        requireUsable();
        return identity -> {
            try (var lease = acquireIo()) {
                requireKafkaProtocolIdentity(identity);
                return provider.readVerifiedObject(identity);
            }
        };
    }

    /** Publication readback is exact full-body verification but is not charged as recovery work. */
    public CanonicalBytes readVerifiedProtocolObjectForPublication(ObjectIdentity identity) throws IOException {
        try (var lease = acquireIo()) {
            requireUsable();
            requireKafkaProtocolIdentity(identity);
            return provider.readVerifiedObject(identity);
        }
    }

    public Sha256Digest rootSha256() {
        return rootSha256;
    }

    public synchronized void chargeRecoveryRoot(boolean predecessor, long canonicalBytes) {
        requireUsable();
        recovery.chargeRoot(predecessor, canonicalBytes);
    }

    public synchronized CumulativeRecoveryBudget.ControlMetadataReservation reserveRecoveryControlMetadata(
            long maximumBytes) {
        requireUsable();
        return recovery.reserveControlMetadata(maximumBytes);
    }

    public synchronized void chargeRecoveryControlMetadata(long canonicalBytes) {
        requireUsable();
        recovery.chargeControlMetadata(canonicalBytes);
    }

    public synchronized void chargeRecoveryDecoded(long contexts, long frames, long commitSets) {
        requireUsable();
        recovery.chargeDecoded(contexts, frames, commitSets);
    }

    /**
     * Stages exact physical checkpoint rows under this session's live recovery budget. Callers must publish staged
     * protocol state only after this method has returned successfully.
     */
    public WalCheckpointChainVerifier.StreamingVerification verifyCheckpointChainStreaming(
            CanonicalControlMetadataStore metadata,
            WalCheckpointHeadV1 head,
            java.util.function.Consumer<ProviderResolvedExtentRowV1> verifiedRowConsumer) {
        try (var lease = acquireIo()) {
            requireUsable();
            return recovery.verifyCheckpointChainStreaming(metadata, head, verifiedRowConsumer);
        }
    }

    /** Streaming descendant proof without retaining a checkpoint page chain. */
    public WalCheckpointChainVerifier.StreamingVerification verifyCheckpointChainDescendant(
            CanonicalControlMetadataStore metadata,
            WalCheckpointHeadV1 head,
            long anchorOrdinal,
            String anchorKey,
            Sha256Digest anchorSha256) {
        try (var lease = acquireIo()) {
            requireUsable();
            if (anchorOrdinal < 0) {
                return recovery.verifyCheckpointChainStreaming(metadata, head, ignored -> {});
            }
            Objects.requireNonNull(anchorKey, "anchorKey");
            Objects.requireNonNull(anchorSha256, "anchorSha256");
            boolean[] found = {false};
            WalCheckpointChainVerifier.StreamingVerification verified =
                    recovery.verifyCheckpointChainStreaming(metadata, head, ignored -> {}, page -> {
                        if (page.ordinal() == anchorOrdinal
                                && page.key().equals(anchorKey)
                                && page.sha256().equals(anchorSha256)) {
                            found[0] = true;
                        }
                    });
            if (!found[0]) {
                throw new IllegalStateException(
                        "checkpoint Head conflict is not a descendant of the exact anchor page");
            }
            return verified;
        }
    }

    public synchronized CumulativeRecoveryBudget.Snapshot enterRecoveryFallback() {
        requireUsable();
        return recovery.enterFallback();
    }

    public synchronized CumulativeRecoveryBudget.Snapshot recoverySnapshot() {
        requireUsable();
        return recovery.snapshot();
    }

    /**
     * Acquires one exact slice of the current Root's live recovery working set. The returned lease is one-use and
     * releases precisely that slice on close, allowing protocol adapters to stage bounded commit spools without a
     * caller-created recovery budget.
     */
    public synchronized RecoveryWorkingSetLease acquireRecoveryWorkingSet(long exactBytes) {
        requireUsable();
        if (exactBytes <= 0) {
            throw new IllegalArgumentException("recovery working-set bytes must be positive");
        }
        recovery.acquireWorkingSet(exactBytes);
        return new RecoveryWorkingSetLease(this, exactBytes);
    }

    public static final class RecoveryWorkingSetLease implements AutoCloseable {
        private final WalRunObjectSession owner;
        private long exactBytes;
        private boolean closed;

        private RecoveryWorkingSetLease(WalRunObjectSession owner, long exactBytes) {
            this.owner = owner;
            this.exactBytes = exactBytes;
        }

        /** Adds bytes to this one spool lease without consuming another recovery-concurrency slot. */
        public void grow(long additionalExactBytes) {
            synchronized (owner) {
                if (closed || additionalExactBytes <= 0) {
                    throw new IllegalStateException("recovery working-set lease is closed or growth is non-positive");
                }
                owner.requireUsable();
                owner.recovery.growWorkingSet(additionalExactBytes);
                exactBytes = Math.addExact(exactBytes, additionalExactBytes);
            }
        }

        /** Releases transformed/discarded bytes while retaining this spool's single concurrency reservation. */
        public void shrink(long releasedExactBytes) {
            synchronized (owner) {
                if (closed || releasedExactBytes <= 0 || releasedExactBytes > exactBytes) {
                    throw new IllegalStateException("recovery working-set lease shrink is invalid");
                }
                owner.requireUsable();
                owner.recovery.shrinkWorkingSet(releasedExactBytes);
                exactBytes = Math.subtractExact(exactBytes, releasedExactBytes);
            }
        }

        @Override
        public void close() {
            synchronized (owner) {
                if (closed) {
                    throw new IllegalStateException("recovery working-set lease was already closed");
                }
                owner.requireUsable();
                owner.recovery.releaseWorkingSet(exactBytes);
                closed = true;
            }
        }
    }

    private void requireVerificationContext(Nwg1VerificationContextV1 context) {
        Objects.requireNonNull(context, "verificationContext");
        if (!context.protocolCell().equals(root.protocolCellIdentity())
                || !Arrays.equals(
                        context.cellProviderScopeId(),
                        root.providerScopeId().digest().bytes().toByteArray())
                || !Arrays.equals(context.walRunRootSha256(), rootSha256.bytes().toByteArray())
                || !Arrays.equals(
                        context.envelope().framedBytes(),
                        root.wrappedRunKey().framedBytes().toByteArray())) {
            throw new IllegalArgumentException("NWG1 verification context differs from the exact WalRun Root");
        }
    }

    private void requireCandidate(AdmittedNwg1Candidate candidate) {
        requireUsable();
        Objects.requireNonNull(candidate, "candidate");
        if (candidate.owner != this
                || candidate.terminal
                || candidate.validatedPlan.candidate != candidate
                || !runtime.retryReservation(
                                candidate.reservation.laneId(),
                                candidate.reservation.laneSequence(),
                                candidate.reservation.canonicalPlanSha256())
                        .equals(candidate.reservation)) {
            throw new IllegalArgumentException("NWG1 candidate is not the exact pending WalRun reservation");
        }
    }

    private static void requireCandidateIdle(AdmittedNwg1Candidate candidate) {
        if (candidate.ioInFlight) {
            throw new IllegalStateException("NWG1 candidate retains in-flight I/O");
        }
    }

    private void chargeConditionalCreateAttempt(int priorAttempts) {
        if (priorAttempts < 0 || priorAttempts >= 2) {
            throw new IllegalStateException("C1 frozen failure model permits only PUT1 plus exact-candidate PUT2");
        }
        if (priorAttempts == 1) {
            recovery.chargeConditionalCreateRetry();
        }
    }

    private void requireKafkaProtocolIdentity(ObjectIdentity identity) {
        Objects.requireNonNull(identity, "identity");
        if (root.protocolCellIdentity().protocolKind().code() != 1 || identity.bodyLength() > 64L * 1024 * 1024) {
            throw new IllegalArgumentException("WalRun does not admit this Kafka protocol Object identity");
        }
        String namespace = root.providerConfiguration().exclusiveNamespacePrefix();
        String marker = "/protocol/kafka/nwkcp1-v1/objects/sha256-v1-";
        int markerOffset = identity.key().lastIndexOf(marker);
        if (markerOffset < namespace.length()
                || !identity.key().startsWith(namespace + "/")
                || markerOffset != identity.key().indexOf(marker)) {
            throw new IllegalArgumentException("Kafka protocol Object key differs from the exact Root-bound grammar");
        }
        String expected = identity.key().substring(0, markerOffset)
                + marker
                + identity.bodySha256().toHex()
                + ".nwkcp1";
        if (!identity.key().equals(expected) || expected.getBytes(StandardCharsets.US_ASCII).length > 1024) {
            throw new IllegalArgumentException("Kafka protocol Object key differs from the exact Root-bound grammar");
        }
    }

    private ProviderVersionProof requireProviderProof(Optional<CanonicalBytes> immutableVersionToken) {
        Objects.requireNonNull(immutableVersionToken, "immutableVersionToken");
        ProviderProofMode mode = root.providerConfiguration().proofMode();
        if (mode == ProviderProofMode.NONE) {
            return ProviderVersionProof.none();
        }
        CanonicalBytes token = immutableVersionToken.orElseThrow(
                () -> new IllegalStateException("Root VERSION proof mode requires an immutable token"));
        if (token.isEmpty() || token.length() > root.providerConfiguration().proofTokenHardCap()) {
            throw new IllegalStateException("Provider immutable token exceeds the exact Root proof cap");
        }
        return new ProviderVersionProof(mode, token);
    }

    private ObjectWalLeafKeyV1 requireNwg1LeafIdentity(ObjectIdentity identity) {
        return requireNwg1LeafIdentity(root, identity);
    }

    static ObjectWalLeafKeyV1 requireNwg1LeafIdentity(WalRunRootRecord root, ObjectIdentity identity) {
        Objects.requireNonNull(identity, "identity");
        ObjectWalLeafKeyV1 leaf = ObjectWalLeafKeyV1.parseFull(root.providerConfiguration(), identity.key());
        if (leaf.bodyLength() != identity.bodyLength() || !leaf.objectSha256().equals(identity.bodySha256())) {
            throw new IllegalArgumentException("NWG1 Object identity differs from its exact Root-bound leaf");
        }
        return leaf;
    }

    static void requirePrefixIdentity(Nwg1ObjectReaderV1.AuthenticatedPrefix prefix, ObjectWalLeafKeyV1 leaf) {
        if (prefix.header().laneId() != leaf.laneId().code()
                || prefix.header().laneSequence() != leaf.laneSequence()
                || prefix.header().directoryPrefixEnd() != leaf.directoryPrefixEnd()
                || prefix.header().canonicalBodyLength() != leaf.bodyLength()) {
            throw new IllegalArgumentException("authenticated NWG1 prefix differs from the exact Object leaf");
        }
    }

    private void requirePrefixWithinRootCaps(Nwg1ObjectReaderV1.AuthenticatedPrefix prefix) {
        requirePrefixWithinRootCaps(root, prefix);
    }

    static void requirePrefixWithinRootCaps(WalRunRootRecord root, Nwg1ObjectReaderV1.AuthenticatedPrefix prefix) {
        Nwg1RootAdmissionCaps caps = root.nwg1AdmissionCaps();
        if (prefix.header().canonicalBodyLength() > caps.maxCanonicalBodyBytes()
                || prefix.header().directoryPrefixEnd() > caps.maxDirectoryPrefixBytes()
                || prefix.header().directoryPlaintextLength() > caps.maxDirectoryPlaintextBytes()
                || prefix.directory().bindings().size() > caps.maxBindingContexts()
                || prefix.directory().appendUnits().size() > caps.maxAppendUnits()
                || prefix.directory().frames().size() > caps.maxFrames()
                || prefix.header().actualPayloadBytesAtPlanSeal() > caps.maxTotalDecodedPayloadBytes()) {
            throw new IllegalArgumentException("authenticated NWG1 Directory exceeds the exact Root caps");
        }
        long[] decodedPerUnit = new long[prefix.directory().appendUnits().size()];
        long decodedTotal = 0;
        for (com.nereusstream.storage.object.nwg1.Nwg1DirectoryV1.Frame frame :
                prefix.directory().frames()) {
            if (frame.decodedPayloadBytes() > caps.maxDecodedFrameBytes()
                    || frame.storedBlockBytes() > caps.maxStoredFrameBytes()
                    || frame.storedBlockBytes() > root.providerConfiguration().maxSingleRangeReadBytes()) {
                throw new IllegalArgumentException("authenticated NWG1 frame exceeds the exact Root caps");
            }
            int unitOrdinal = Math.toIntExact(frame.appendUnitOrdinal());
            decodedPerUnit[unitOrdinal] = Math.addExact(decodedPerUnit[unitOrdinal], frame.decodedPayloadBytes());
            decodedTotal = Math.addExact(decodedTotal, frame.decodedPayloadBytes());
        }
        for (long decodedBytes : decodedPerUnit) {
            if (decodedBytes > caps.maxDecodedAppendUnitBytes()) {
                throw new IllegalArgumentException("authenticated NWG1 append unit exceeds the exact Root caps");
            }
        }
        if (decodedTotal != prefix.header().actualPayloadBytesAtPlanSeal()
                || decodedTotal > caps.maxTotalDecodedPayloadBytes()) {
            throw new IllegalArgumentException("authenticated NWG1 decoded total differs from the exact Root caps");
        }
    }

    private void requireOpen() {
        if (state != State.OPEN) {
            throw new IllegalStateException("WalRun Object session does not accept new work: " + state);
        }
    }

    private void requireUsable() {
        if (state == State.CLOSED) {
            throw new IllegalStateException("WalRun Object session is closed");
        }
    }

    /** Stops new admission while preserving KMS keys and existing Provider unknown operations for reconciliation. */
    public synchronized void drain() {
        if (state == State.CLOSED || state == State.DRAINING) {
            return;
        }
        if (runtime.state() == WalRunRuntime.State.ADMITTING) {
            runtime.stopAdmission(WalRunRuntime.StopReason.OWNER_REQUEST);
        }
        provider.drain();
        state = State.DRAINING;
    }

    public synchronized State state() {
        return state;
    }

    /** Exact immutable Root already verified by this owner; recovery adapters must not reload or recharge it. */
    public synchronized WalRunRootRecord rootRecord() {
        requireUsable();
        return root;
    }

    /** Fail-closed guard for owner-open recovery entry points that must continue a lineage-carried live budget. */
    public synchronized void requireRecoveredCurrentRoot() {
        requireUsable();
        if (!recoveredCurrentRoot) {
            throw new IllegalStateException(
                    "owner-open recovery requires a WalRun session restored from RecoveredLineage");
        }
    }

    /** Exact Root authority for checkpoint proof projection; adapters must not restate this mode. */
    public synchronized ProviderProofMode providerProofMode() {
        requireUsable();
        return root.providerConfiguration().proofMode();
    }

    public static final class ValidatedNwg1Plan {
        private final WalRunObjectSession owner;
        private final GroupEncodingPlanV1 plan;
        private final Nwg1VerificationContextV1 verificationContext;
        private final ImmutableExtentPlan immutablePlan;
        private final GroupEncodingPlanV1.AdmissionFacts facts;
        private LaneSequenceReservation reservation;
        private AdmittedNwg1Candidate candidate;
        private boolean sealing;

        private ValidatedNwg1Plan(
                WalRunObjectSession owner,
                GroupEncodingPlanV1 plan,
                Nwg1VerificationContextV1 verificationContext,
                ImmutableExtentPlan immutablePlan,
                GroupEncodingPlanV1.AdmissionFacts facts) {
            this.owner = owner;
            this.plan = plan;
            this.verificationContext = verificationContext;
            this.immutablePlan = immutablePlan;
            this.facts = facts;
        }

        public Sha256Digest canonicalPlanSha256() {
            return immutablePlan.canonicalPlanSha256();
        }

        public long canonicalBodyBytes() {
            return facts.canonicalBodyBytes();
        }

        public Optional<LaneSequenceReservation> sequenceEffect() {
            return Optional.ofNullable(reservation);
        }
    }

    /**
     * Unforgeable one-shot capability used only to bind a KMS lease to this exact WalRun owner. The constructor is
     * private and no session API exposes an instance.
     */
    public static final class KmsOwnerAuthority {
        private final WalRunObjectSession owner;
        private final RunKeyCacheIdentity runKeyIdentity;
        private final WrappedRunKeyEnvelope wrappedRunKey;
        private final Sha256Digest rootSha256;
        private final CellProviderScopeId providerScopeId;

        private KmsOwnerAuthority(
                WalRunObjectSession owner,
                RunKeyCacheIdentity runKeyIdentity,
                WrappedRunKeyEnvelope wrappedRunKey,
                Sha256Digest rootSha256,
                CellProviderScopeId providerScopeId) {
            this.owner = Objects.requireNonNull(owner, "owner");
            this.runKeyIdentity = Objects.requireNonNull(runKeyIdentity, "runKeyIdentity");
            this.wrappedRunKey = Objects.requireNonNull(wrappedRunKey, "wrappedRunKey");
            this.rootSha256 = Objects.requireNonNull(rootSha256, "rootSha256");
            this.providerScopeId = Objects.requireNonNull(providerScopeId, "providerScopeId");
        }

        public RunKeyCacheIdentity runKeyIdentity() {
            requireLiveOwner();
            return runKeyIdentity;
        }

        public WrappedRunKeyEnvelope wrappedRunKey() {
            requireLiveOwner();
            return wrappedRunKey;
        }

        public Sha256Digest rootSha256() {
            requireLiveOwner();
            return rootSha256;
        }

        public CellProviderScopeId providerScopeId() {
            requireLiveOwner();
            return providerScopeId;
        }

        private void requireLiveOwner() {
            if (owner.kms != null) {
                throw new IllegalStateException("KMS owner authority has already been consumed");
            }
        }
    }

    /** Unforgeable one-shot capability binding a raw C1 Provider to this exact WalRun owner. */
    public static final class ProviderOwnerAuthority {
        private final WalRunObjectSession owner;
        private final CellProviderScopeId providerScopeId;
        private final String exclusiveNamespacePrefix;
        private final long admittedMaximumObjectBytes;
        private final int admittedMaximumPrefixBytes;

        private ProviderOwnerAuthority(
                WalRunObjectSession owner,
                CellProviderScopeId providerScopeId,
                String exclusiveNamespacePrefix,
                long admittedMaximumObjectBytes,
                int admittedMaximumPrefixBytes) {
            this.owner = Objects.requireNonNull(owner, "owner");
            this.providerScopeId = Objects.requireNonNull(providerScopeId, "providerScopeId");
            this.exclusiveNamespacePrefix =
                    Objects.requireNonNull(exclusiveNamespacePrefix, "exclusiveNamespacePrefix");
            this.admittedMaximumObjectBytes = admittedMaximumObjectBytes;
            this.admittedMaximumPrefixBytes = admittedMaximumPrefixBytes;
        }

        public CellProviderScopeId providerScopeId() {
            requireLiveOwner();
            return providerScopeId;
        }

        public String exclusiveNamespacePrefix() {
            requireLiveOwner();
            return exclusiveNamespacePrefix;
        }

        public long admittedMaximumObjectBytes() {
            requireLiveOwner();
            return admittedMaximumObjectBytes;
        }

        public int admittedMaximumPrefixBytes() {
            requireLiveOwner();
            return admittedMaximumPrefixBytes;
        }

        public Sha256Digest rootSha256() {
            requireLiveOwner();
            return owner.rootSha256;
        }

        private void requireLiveOwner() {
            if (owner.provider != null) {
                throw new IllegalStateException("Provider owner authority has already been consumed");
            }
        }
    }

    public static final class AdmittedNwg1Candidate {
        private final WalRunObjectSession owner;
        private final ValidatedNwg1Plan validatedPlan;
        private final LaneSequenceReservation reservation;
        private final Nwg1SealedObjectV1 sealed;
        private final ObjectIdentity identity;
        private final RepeatableObjectBody uploadBody;
        private ProviderObjectResult persistenceResult;
        private int liveReconciliations;
        private boolean ioInFlight;
        private int conditionalCreateAttempts;
        private boolean terminal;

        private AdmittedNwg1Candidate(
                WalRunObjectSession owner,
                ValidatedNwg1Plan validatedPlan,
                LaneSequenceReservation reservation,
                Nwg1SealedObjectV1 sealed,
                ObjectIdentity identity) {
            this.owner = owner;
            this.validatedPlan = validatedPlan;
            this.reservation = reservation;
            this.sealed = sealed;
            this.identity = identity;
            this.uploadBody = new SealedNwg1CandidateBody(identity, sealed);
        }

        public LaneSequenceReservation reservation() {
            return reservation;
        }

        public Nwg1SealedObjectV1 sealed() {
            return sealed;
        }

        public ObjectIdentity identity() {
            return identity;
        }
    }

    /** Unforgeable shared publication proof retained only until the exact candidate becomes terminal. */
    public static final class AuthenticatedNwg1PublicationExtent {
        private final WalRunObjectSession owner;
        private final AdmittedNwg1Candidate candidate;
        private final Nwg1ObjectReaderV1.AuthenticatedPrefix prefix;
        private final byte[] exactBody;
        private final ProviderVersionProof providerProof;

        private AuthenticatedNwg1PublicationExtent(
                WalRunObjectSession owner,
                AdmittedNwg1Candidate candidate,
                Nwg1ObjectReaderV1.AuthenticatedPrefix prefix,
                byte[] exactBody,
                ProviderVersionProof providerProof) {
            this.owner = Objects.requireNonNull(owner, "owner");
            this.candidate = Objects.requireNonNull(candidate, "candidate");
            this.prefix = Objects.requireNonNull(prefix, "prefix");
            this.exactBody = exactBody;
            this.providerProof = Objects.requireNonNull(providerProof, "providerProof");
        }

        public ObjectIdentity identity() {
            return candidate.identity;
        }

        public Nwg1ObjectReaderV1.AuthenticatedPrefix authenticatedPrefix() {
            return prefix;
        }

        public ProviderVersionProof providerProof() {
            return providerProof;
        }
    }

    public static final class ValidatedKafkaProtocolObject {
        private final WalRunObjectSession owner;
        private final ObjectIdentity identity;
        private final CanonicalBytes body;
        private int conditionalCreateAttempts;
        private boolean ioInFlight;

        private ValidatedKafkaProtocolObject(WalRunObjectSession owner, ObjectIdentity identity, CanonicalBytes body) {
            this.owner = owner;
            this.identity = identity;
            this.body = CanonicalBytes.copyOf(body.toByteArray());
        }

        public ObjectIdentity identity() {
            return identity;
        }
    }

    public static final class Nwg1AdmissionFailure extends IllegalStateException {
        private final Optional<LaneSequenceReservation> sequenceEffect;
        private final Sha256Digest canonicalPlanSha256;

        private Nwg1AdmissionFailure(
                Optional<LaneSequenceReservation> sequenceEffect,
                Sha256Digest canonicalPlanSha256,
                RuntimeException cause) {
            super("NWG1 admission/seal failed", cause);
            this.sequenceEffect = Objects.requireNonNull(sequenceEffect, "sequenceEffect");
            this.canonicalPlanSha256 = Objects.requireNonNull(canonicalPlanSha256, "canonicalPlanSha256");
        }

        public Optional<LaneSequenceReservation> sequenceEffect() {
            return sequenceEffect;
        }

        public Sha256Digest canonicalPlanSha256() {
            return canonicalPlanSha256;
        }
    }

    private record CanonicalCandidateBody(ObjectIdentity identity, CanonicalBytes bytes)
            implements RepeatableObjectBody {
        private CanonicalCandidateBody {
            Objects.requireNonNull(identity, "identity");
            Objects.requireNonNull(bytes, "bytes");
        }

        @Override
        public InputStream openStream() {
            return new ByteArrayInputStream(bytes.toByteArray());
        }
    }

    private record SealedNwg1CandidateBody(ObjectIdentity identity, Nwg1SealedObjectV1 sealed)
            implements RepeatableObjectBody {
        @Override
        public InputStream openStream() {
            return sealed.openBodyStream();
        }
    }

    @Override
    public synchronized void close() {
        if (state == State.CLOSED) {
            return;
        }
        drain();
        if (activeIo != 0 || provider.acceptedOperations() != 0 || provider.unknownObjectCount() != 0) {
            throw new IllegalStateException(
                    "WalRun Object session retains Provider operations; reconcile before close");
        }
        checkpointPublishers.forEach(WalCheckpointPublisher::close);
        if (recoveredCut != null && !recoveredRowsReleased) {
            recoveredCut.discardUnconsumedPhysicalRows();
            recovery.finishRecoveredPhysicalRows();
            recoveredRowsReleased = true;
        }
        provider.close();
        kms.close();
        state = State.CLOSED;
    }
}
