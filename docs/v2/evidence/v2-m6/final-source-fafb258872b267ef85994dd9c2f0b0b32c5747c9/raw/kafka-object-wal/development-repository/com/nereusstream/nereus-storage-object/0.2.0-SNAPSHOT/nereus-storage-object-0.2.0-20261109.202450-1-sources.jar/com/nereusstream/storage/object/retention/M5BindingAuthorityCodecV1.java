/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.storage.object.retention;

import com.nereusstream.domain.bytes.CanonicalBytes;
import com.nereusstream.domain.bytes.Sha256Digest;
import com.nereusstream.storage.object.read.control.M4ReadControlCodecV1;
import com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.BindingReadSelector;
import com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.CapabilityBinding;
import com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.SourceRetirementBatch;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.BatchAuthoritySlotV1;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.BindingAuthorityStateV1;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.BindingRetirementAuthorityV1;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.ReferenceMutationTicketV1;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.ReferenceScanFenceV1;
import com.nereusstream.storage.object.retention.M5BindingAuthorityRecordsV1.ReferenceWriterEnrollmentV1;
import com.nereusstream.storage.object.retention.M5RetentionRecordsV1.BatchMetadataStateV1;
import com.nereusstream.storage.object.retention.M5RetentionRecordsV1.FloorClassV1;
import com.nereusstream.storage.object.retention.M5RetentionRecordsV1.ReferenceKindV1;
import com.nereusstream.storage.object.retention.M5RetentionRecordsV1.ReferenceTargetKindV1;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/** Strict canonical wire and legacy-selector projection for the single Binding authority cell. */
public final class M5BindingAuthorityCodecV1 {
    private static final int MAGIC = 0x4d355231; // M5R1
    private static final int VERSION = 2;
    private static final Sha256Digest PLACEHOLDER = Sha256Digest.copyOf(new byte[Sha256Digest.LENGTH]);

    private M5BindingAuthorityCodecV1() {}

    public static boolean isAuthorityValue(CanonicalBytes value) {
        byte[] bytes = value.toByteArray();
        if (bytes.length < Integer.BYTES) {
            return false;
        }
        int magic =
                ((bytes[0] & 0xff) << 24) | ((bytes[1] & 0xff) << 16) | ((bytes[2] & 0xff) << 8) | (bytes[3] & 0xff);
        return magic == MAGIC;
    }

    public static BindingRetirementAuthorityV1 initial(BindingReadSelector selector) {
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                selector.binding(),
                1,
                Optional.empty(),
                BindingAuthorityStateV1.OPEN_V1,
                selector,
                fullSlots(selector.activeBatches()),
                Optional.empty(),
                List.of(),
                Optional.empty(),
                selector.capability(),
                PLACEHOLDER));
    }

    /** Activate the original initialization fence only after the first real selected view exists. */
    public static BindingRetirementAuthorityV1 activateBootstrap(
            M5BindingBootstrapV1 bootstrap, BindingReadSelector selector) {
        if (!bootstrap.binding().equals(selector.binding())
                || !bootstrap.capability().equals(selector.capability())
                || selector.readAdmissionEpoch() != 1
                || selector.sourceGeneration() != 1
                || selector.mode()
                        != com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.SelectorMode
                                .PREFERRED_ONLY
                || selector.admissionState()
                        != com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.AdmissionState.ADMITTING
                || !selector.activeBatches().isEmpty()
                || !selector.pendingAnchors().isEmpty()) {
            throw new IllegalArgumentException("bootstrap activation requires the first exact Binding selector");
        }
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                selector.binding(),
                1,
                Optional.of(Sha256Digest.hash(bootstrap.encode())),
                BindingAuthorityStateV1.OPEN_V1,
                selector,
                List.of(),
                Optional.empty(),
                List.of(),
                Optional.empty(),
                selector.capability(),
                bootstrap.kafkaPolicy().isPresent() ? 7 : 6,
                0,
                M5RetiredBatchHistoryV2.emptyRoot(selector.binding()),
                Optional.empty(),
                Optional.empty(),
                PLACEHOLDER,
                Optional.empty(),
                List.of(),
                Optional.of(bootstrap)));
    }

    /** Startup provenance is immutable, and cannot be attached to an existing selector. */
    public static void requireBootstrapTransition(
            BindingRetirementAuthorityV1 current, BindingRetirementAuthorityV1 next) {
        if (!current.bootstrap().equals(next.bootstrap())) {
            throw new IllegalArgumentException("Binding startup provenance cannot be changed or imported");
        }
    }

    /** Wrap one exact legacy selector without changing its M4 projection bytes. */
    public static BindingRetirementAuthorityV1 migrateLegacy(CanonicalBytes exactLegacySelector) {
        BindingReadSelector selector = M4ReadControlCodecV1.decodeSelector(exactLegacySelector);
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                selector.binding(),
                1,
                Optional.of(Sha256Digest.hash(exactLegacySelector)),
                BindingAuthorityStateV1.OPEN_V1,
                selector,
                fullSlots(selector.activeBatches()),
                Optional.empty(),
                List.of(),
                Optional.empty(),
                selector.capability(),
                PLACEHOLDER));
    }

    /** Apply an M4 selector successor while preserving every M5-only slot/ticket field. */
    public static BindingRetirementAuthorityV1 selectorSuccessor(
            BindingRetirementAuthorityV1 current, BindingReadSelector successor) {
        return selectorSuccessor(current, successor, id -> {
            if (current.retiredHistory().count() != 0) {
                throw new IllegalStateException(
                        "selector admission requires a proof against the exact retired history");
            }
            return new M5RetiredBatchHistoryV2(current.binding())
                    .readProof(current.retiredHistory(), id, key -> Optional.empty());
        });
    }

    public static BindingRetirementAuthorityV1 selectorSuccessor(
            BindingRetirementAuthorityV1 current,
            BindingReadSelector successor,
            java.util.function.Function<Sha256Digest, M5RetiredBatchHistoryV2.Proof> historyProof) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1) {
            throw new IllegalStateException("REFERENCE_SCAN_FENCED_V1 blocks Binding control mutation");
        }
        if (!current.binding().equals(successor.binding())
                || !current.capability().equals(successor.capability())) {
            throw new IllegalArgumentException("selector successor changes Binding or capability");
        }
        List<SourceRetirementBatch> existingFull = current.batchSlots().stream()
                .filter(slot -> slot.state() == BatchMetadataStateV1.FULL_V1)
                .map(BatchAuthoritySlotV1::fullBatch)
                .toList();
        if (successor.activeBatches().size() < existingFull.size()
                || !successor.activeBatches().subList(0, existingFull.size()).equals(existingFull)) {
            throw new IllegalArgumentException("M4 selector successor removes or reorders a FULL_V1 authority slot");
        }
        List<BatchAuthoritySlotV1> slots = new ArrayList<>(current.batchSlots());
        long ordinal = current.lastActivationOrdinal();
        for (SourceRetirementBatch batch : successor
                .activeBatches()
                .subList(existingFull.size(), successor.activeBatches().size())) {
            if (slots.stream().anyMatch(slot -> slot.batchIdSha256().equals(batch.batchIdSha256()))) {
                throw new IllegalArgumentException("selector successor reuses a retired or existing BatchId slot");
            }
            var proof = historyProof.apply(batch.batchIdSha256());
            new M5RetiredBatchHistoryV2(current.binding())
                    .verify(current.retiredHistory(), batch.batchIdSha256(), proof);
            if (!proof.batchId().equals(batch.batchIdSha256())
                    || proof.tombstone().isPresent()) {
                throw new IllegalArgumentException("selector successor reuses a historical BatchId");
            }
            slots.add(BatchAuthoritySlotV1.full(++ordinal, batch));
        }
        return buildSuccessor(
                current,
                BindingAuthorityStateV1.OPEN_V1,
                successor,
                slots,
                Optional.empty(),
                current.referenceMutationTickets(),
                current.writerEnrollment());
    }

    /** Apply a successor directly to one legacy predecessor in the migration CAS. */
    public static BindingRetirementAuthorityV1 migrateLegacyWithSuccessor(
            CanonicalBytes exactLegacySelector, BindingReadSelector successor) {
        BindingReadSelector predecessor = M4ReadControlCodecV1.decodeSelector(exactLegacySelector);
        if (!predecessor.binding().equals(successor.binding())
                || !predecessor.capability().equals(successor.capability())
                || successor.activeBatches().size()
                        < predecessor.activeBatches().size()
                || !successor
                        .activeBatches()
                        .subList(0, predecessor.activeBatches().size())
                        .equals(predecessor.activeBatches())) {
            throw new IllegalArgumentException("legacy migration successor changes existing batch authority");
        }
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                successor.binding(),
                1,
                Optional.of(Sha256Digest.hash(exactLegacySelector)),
                BindingAuthorityStateV1.OPEN_V1,
                successor,
                fullSlots(successor.activeBatches()),
                Optional.empty(),
                List.of(),
                Optional.empty(),
                successor.capability(),
                PLACEHOLDER));
    }

    public static BindingRetirementAuthorityV1 successor(
            BindingRetirementAuthorityV1 current,
            BindingAuthorityStateV1 state,
            BindingReadSelector selector,
            List<BatchAuthoritySlotV1> slots,
            Optional<ReferenceScanFenceV1> fence,
            List<ReferenceMutationTicketV1> tickets) {
        return successor(current, state, selector, slots, fence, tickets, current.writerEnrollment());
    }

    public static BindingRetirementAuthorityV1 successor(
            BindingRetirementAuthorityV1 current,
            BindingAuthorityStateV1 state,
            BindingReadSelector selector,
            List<BatchAuthoritySlotV1> slots,
            Optional<ReferenceScanFenceV1> fence,
            List<ReferenceMutationTicketV1> tickets,
            Optional<ReferenceWriterEnrollmentV1> enrollment) {
        if (slots.size() != current.batchSlots().size()
                || slots.stream()
                        .anyMatch(slot -> current.slot(slot.batchIdSha256()).isEmpty())) {
            throw new IllegalArgumentException("new BatchId admission must verify the exact current history proof");
        }
        return buildSuccessor(current, state, selector, slots, fence, tickets, enrollment);
    }

    private static BindingRetirementAuthorityV1 buildSuccessor(
            BindingRetirementAuthorityV1 current,
            BindingAuthorityStateV1 state,
            BindingReadSelector selector,
            List<BatchAuthoritySlotV1> slots,
            Optional<ReferenceScanFenceV1> fence,
            List<ReferenceMutationTicketV1> tickets,
            Optional<ReferenceWriterEnrollmentV1> enrollment) {
        for (BatchAuthoritySlotV1 old : current.batchSlots()) {
            var retained = slots.stream()
                    .filter(slot -> slot.batchIdSha256().equals(old.batchIdSha256()))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("only a history fold may remove a slot"));
            if (retained.activationOrdinal() != old.activationOrdinal()
                    || !retained.fullBatchSha256().equals(old.fullBatchSha256())
                    || retained.state() == BatchMetadataStateV1.FULL_V1 && !retained.equals(old)
                    || old.state() == BatchMetadataStateV1.RETIRED_V1 && !retained.equals(old)) {
                throw new IllegalArgumentException("ordinary authority successor changed permanent retirement history");
            }
        }
        CanonicalBytes predecessor = encodeAuthority(current);
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                current.binding(),
                Math.addExact(current.authorityGeneration(), 1),
                Optional.of(Sha256Digest.hash(predecessor)),
                state,
                selector,
                slots,
                fence,
                tickets,
                enrollment,
                current.capability(),
                Math.max(VERSION, current.wireVersion()),
                Math.addExact(current.retiredHistory().count(), slots.size()),
                current.retiredHistory(),
                current.taskSelectionDecision(),
                current.materializationWorker(),
                PLACEHOLDER,
                current.logicalTrim(),
                current.trimMutationTickets(),
                current.bootstrap(),
                current.kafkaPolicy(),
                current.sourceScan()));
    }

    static BindingRetirementAuthorityV1 fold(
            BindingRetirementAuthorityV1 current,
            BatchAuthoritySlotV1 terminal,
            M5RetiredBatchHistoryV2.Insertion insertion) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                || !current.batchSlots().contains(terminal)
                || terminal.state() != BatchMetadataStateV1.RETIRED_V1
                || !insertion.predecessor().equals(current.retiredHistory())
                || !insertion.absenceProof().batchId().equals(terminal.batchIdSha256())
                || current.referenceMutationTickets().stream()
                        .anyMatch(ticket -> ticket.targetIdentitySha256().equals(terminal.batchIdSha256()))) {
            throw new IllegalArgumentException("history fold lacks one unreferenced exact terminal slot");
        }
        var history = new M5RetiredBatchHistoryV2(current.binding());
        var expected = history.insert(
                current.retiredHistory(), terminal.retiredTombstone().orElseThrow(), insertion.absenceProof());
        if (!expected.equals(insertion)) {
            throw new IllegalArgumentException("history fold insertion differs from the exact terminal tombstone");
        }
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                current.binding(),
                Math.addExact(current.authorityGeneration(), 1),
                Optional.of(Sha256Digest.hash(encodeAuthority(current))),
                current.state(),
                current.selectorProjection(),
                current.batchSlots().stream()
                        .filter(slot -> !slot.equals(terminal))
                        .toList(),
                current.scanFence(),
                current.referenceMutationTickets(),
                current.writerEnrollment(),
                current.capability(),
                Math.max(VERSION, current.wireVersion()),
                current.lastActivationOrdinal(),
                insertion.successor(),
                current.taskSelectionDecision(),
                current.materializationWorker(),
                PLACEHOLDER,
                current.logicalTrim(),
                current.trimMutationTickets(),
                current.bootstrap(),
                current.kafkaPolicy(),
                current.sourceScan()));
    }

    /** Validates the inline transition shape; the native route separately checks immutable archive authority. */
    public static void requireTaskSelectionTransition(
            BindingRetirementAuthorityV1 current, BindingRetirementAuthorityV1 successor) {
        requireBootstrapTransition(current, successor);
        requireKafkaPolicyTransition(current, successor);
        if (successor.wireVersion() < current.wireVersion()) {
            throw new IllegalArgumentException("Binding authority cannot downgrade its task-decision wire version");
        }
        if (current.taskSelectionDecision().equals(successor.taskSelectionDecision())) {
            return;
        }
        if (current.taskSelectionDecision().isPresent()
                && successor.taskSelectionDecision().isPresent()) {
            throw new IllegalArgumentException("inline task selection decision cannot be replaced");
        }
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                || successor.state() != current.state()
                || !successor.batchSlots().equals(current.batchSlots())
                || !successor.retiredHistory().equals(current.retiredHistory())
                || successor.lastActivationOrdinal() != current.lastActivationOrdinal()
                || !successor.scanFence().equals(current.scanFence())
                || !successor.referenceMutationTickets().equals(current.referenceMutationTickets())
                || !successor.writerEnrollment().equals(current.writerEnrollment())
                || !successor.materializationWorker().equals(current.materializationWorker())
                || !successor.capability().equals(current.capability())) {
            throw new IllegalArgumentException("task selection transition changes another authority domain");
        }
        if (successor.taskSelectionDecision().isPresent()) {
            var decision = successor.taskSelectionDecision().orElseThrow();
            if (decision.outcome() == M5TaskSelectionDecisionV2.Outcome.SELECTED
                    && current.materializationWorker().isPresent()) {
                var worker = current.materializationWorker().orElseThrow();
                if (!worker.taskIdSha256().equals(decision.taskId())
                        || !worker.predecessorSelectorSha256()
                                .equals(Sha256Digest.hash(
                                        M4ReadControlCodecV1.encodeSelector(current.selectorProjection())))) {
                    throw new IllegalArgumentException("task selection differs from its admitted worker/selector");
                }
            }
            if (!decision.equals(M5TaskSelectionDecisionV2.of(
                            decision.taskId(),
                            decision.outcome(),
                            current.selectorProjection(),
                            successor.selectorProjection()))
                    || decision.outcome() == M5TaskSelectionDecisionV2.Outcome.SELECTED
                            && successor.selectorProjection().sourceGeneration()
                                    <= current.selectorProjection().sourceGeneration()) {
                throw new IllegalArgumentException("task selection decision does not bind its exact selector CAS");
            }
        } else if (!successor.selectorProjection().equals(current.selectorProjection())) {
            throw new IllegalArgumentException("task selection archival cannot change its read selector");
        }
    }

    /** Adds one bounded decision anchor to an already validated exact selector successor. */
    public static BindingRetirementAuthorityV1 anchorTaskSelection(
            BindingRetirementAuthorityV1 current,
            BindingRetirementAuthorityV1 successor,
            M5TaskSelectionDecisionV2 decision) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                || current.taskSelectionDecision().isPresent()
                || successor.taskSelectionDecision().isPresent()
                || !successor.binding().equals(current.binding())
                || successor.authorityGeneration() != Math.addExact(current.authorityGeneration(), 1)
                || !successor.predecessorValueSha256().equals(Optional.of(Sha256Digest.hash(encodeAuthority(current))))
                || !decision.equals(M5TaskSelectionDecisionV2.of(
                        decision.taskId(),
                        decision.outcome(),
                        current.selectorProjection(),
                        successor.selectorProjection()))) {
            throw new IllegalArgumentException(
                    "task selection lacks an empty exact predecessor and matching successor");
        }
        if (decision.outcome() == M5TaskSelectionDecisionV2.Outcome.SELECTED
                && successor.selectorProjection().sourceGeneration()
                        <= current.selectorProjection().sourceGeneration()) {
            throw new IllegalArgumentException("selected task must advance its source generation");
        }
        var anchored = withTaskSelection(successor, Optional.of(decision));
        requireTaskSelectionTransition(current, anchored);
        return anchored;
    }

    /** Clearing is allowed only after the caller authoritatively rereads these exact immutable archive bytes. */
    public static BindingRetirementAuthorityV1 clearArchivedTaskSelection(
            BindingRetirementAuthorityV1 current, CanonicalBytes exactArchive) {
        var decision = current.taskSelectionDecision().orElseThrow();
        if (!decision.encode().equals(exactArchive) || current.state() != BindingAuthorityStateV1.OPEN_V1) {
            throw new IllegalArgumentException("task selection archive differs or Binding is fenced");
        }
        var successor = buildSuccessor(
                current,
                current.state(),
                current.selectorProjection(),
                current.batchSlots(),
                current.scanFence(),
                current.referenceMutationTickets(),
                current.writerEnrollment());
        return withTaskSelection(successor, Optional.empty());
    }

    private static BindingRetirementAuthorityV1 withTaskSelection(
            BindingRetirementAuthorityV1 value, Optional<M5TaskSelectionDecisionV2> decision) {
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                value.binding(),
                value.authorityGeneration(),
                value.predecessorValueSha256(),
                value.state(),
                value.selectorProjection(),
                value.batchSlots(),
                value.scanFence(),
                value.referenceMutationTickets(),
                value.writerEnrollment(),
                value.capability(),
                Math.max(3, value.wireVersion()),
                value.lastActivationOrdinal(),
                value.retiredHistory(),
                decision,
                value.materializationWorker(),
                PLACEHOLDER,
                value.logicalTrim(),
                value.trimMutationTickets(),
                value.bootstrap(),
                value.kafkaPolicy(),
                value.sourceScan()));
    }

    /** A replacement worker competes with publication on the same exact authority CAS. */
    public static BindingRetirementAuthorityV1 admitWorker(
            BindingRetirementAuthorityV1 current, M5MaterializationWorkerV1 worker) {
        var successor = buildSuccessor(
                current,
                current.state(),
                current.selectorProjection(),
                current.batchSlots(),
                current.scanFence(),
                current.referenceMutationTickets(),
                current.writerEnrollment());
        var admitted = finalizeAuthority(new BindingRetirementAuthorityV1(
                successor.binding(),
                successor.authorityGeneration(),
                successor.predecessorValueSha256(),
                successor.state(),
                successor.selectorProjection(),
                successor.batchSlots(),
                successor.scanFence(),
                successor.referenceMutationTickets(),
                successor.writerEnrollment(),
                successor.capability(),
                Math.max(4, successor.wireVersion()),
                successor.lastActivationOrdinal(),
                successor.retiredHistory(),
                successor.taskSelectionDecision(),
                Optional.of(worker),
                PLACEHOLDER,
                successor.logicalTrim(),
                successor.trimMutationTickets(),
                successor.bootstrap(),
                successor.kafkaPolicy(),
                successor.sourceScan()));
        requireWorkerTransition(current, admitted);
        return admitted;
    }

    /** Ordinary M4/retention transitions preserve the last grant, including after it becomes stale. */
    public static void requireWorkerTransition(
            BindingRetirementAuthorityV1 current, BindingRetirementAuthorityV1 successor) {
        if (successor.wireVersion() < current.wireVersion()) {
            throw new IllegalArgumentException("Binding authority cannot downgrade its worker wire version");
        }
        if (successor.materializationWorker().equals(current.materializationWorker())) {
            return;
        }
        if (successor.materializationWorker().isEmpty()
                || current.state() != BindingAuthorityStateV1.OPEN_V1
                || successor.state() != current.state()
                || !successor.selectorProjection().equals(current.selectorProjection())
                || !successor.batchSlots().equals(current.batchSlots())
                || !successor.retiredHistory().equals(current.retiredHistory())
                || successor.lastActivationOrdinal() != current.lastActivationOrdinal()
                || !successor.scanFence().equals(current.scanFence())
                || !successor.referenceMutationTickets().equals(current.referenceMutationTickets())
                || !successor.writerEnrollment().equals(current.writerEnrollment())
                || !successor.taskSelectionDecision().equals(current.taskSelectionDecision())
                || !successor.capability().equals(current.capability())) {
            throw new IllegalArgumentException("worker admission changes another authority domain or clears its epoch");
        }
        var worker = successor.materializationWorker().orElseThrow();
        var selector = current.selectorProjection();
        long epoch = current.materializationWorker()
                .map(value -> value.identity().workerEpoch())
                .orElse(0L);
        if (selector.admissionState()
                        != com.nereusstream.storage.object.read.control.M4ReadControlRecordsV1.AdmissionState.ADMITTING
                || worker.identity().workerEpoch() != Math.addExact(epoch, 1)
                || worker.identity().ownerEpoch() != selector.ownerEpoch()
                || !worker.identity().binding().equals(current.binding())
                || !worker.identity().capability().equals(current.capability())
                || !worker.predecessorSelectorSha256()
                        .equals(Sha256Digest.hash(M4ReadControlCodecV1.encodeSelector(selector)))) {
            throw new IllegalArgumentException(
                    "worker admission lacks the exact current owner/selector and next epoch");
        }
        current.materializationWorker().ifPresent(previous -> {
            if (!worker.identity()
                            .protocolCellSha256()
                            .equals(previous.identity().protocolCellSha256())
                    || !worker.identity()
                            .providerScopeSha256()
                            .equals(previous.identity().providerScopeSha256())
                    || worker.identity().storageFence() != previous.identity().storageFence()
                    || !worker.nativeNamespaceBindingSha256().equals(previous.nativeNamespaceBindingSha256())) {
                throw new IllegalArgumentException("worker admission changes its immutable native Cell/storage scope");
            }
        });
    }

    private static void requireKafkaPolicyTransition(
            BindingRetirementAuthorityV1 current, BindingRetirementAuthorityV1 next) {
        if (current.kafkaPolicy().equals(next.kafkaPolicy())
                && current.sourceScan().equals(next.sourceScan())) {
            return;
        }
        BindingRetirementAuthorityV1 expected;
        if (!current.kafkaPolicy().equals(next.kafkaPolicy())) {
            expected = kafkaPolicySuccessor(
                    current,
                    next.kafkaPolicy()
                            .orElseThrow(() -> new IllegalArgumentException("Kafka policy cannot be removed")));
        } else if (next.sourceScan().isPresent()) {
            expected =
                    sourceScanSuccessor(current, next.sourceScan().orElseThrow().attemptId());
        } else {
            expected = abortSourceScan(current);
        }
        if (!encodeAuthority(expected).equals(encodeAuthority(next))) {
            throw new IllegalArgumentException("Kafka policy/scan transition changed unrelated authority fields");
        }
    }

    public static BindingRetirementAuthorityV1 kafkaPolicySuccessor(
            BindingRetirementAuthorityV1 current, M5KafkaBindingPolicyV1 policy) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                || !current.referenceMutationTickets().isEmpty()
                || !current.trimMutationTickets().isEmpty()
                || current.kafkaPolicy().isEmpty()
                || policy.generation()
                        != Math.addExact(current.kafkaPolicy().orElseThrow().generation(), 1)) {
            throw new IllegalArgumentException("Kafka policy update requires its exact quiescent OPEN generation");
        }
        return kafkaPolicyState(current, BindingAuthorityStateV1.OPEN_V1, policy, Optional.empty());
    }

    public static BindingRetirementAuthorityV1 sourceScanSuccessor(
            BindingRetirementAuthorityV1 current, Sha256Digest attemptId) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                || current.kafkaPolicy().isEmpty()
                || current.writerEnrollment().isEmpty()
                || !current.referenceMutationTickets().isEmpty()
                || !current.trimMutationTickets().isEmpty()) {
            throw new IllegalArgumentException("Kafka source scan requires its quiescent enrolled policy authority");
        }
        return kafkaPolicyState(
                current,
                BindingAuthorityStateV1.SOURCE_SCAN_FENCED_V2,
                current.kafkaPolicy().orElseThrow(),
                Optional.of(new M5BindingAuthorityRecordsV1.BindingSourceScanFenceV2(
                        attemptId, Sha256Digest.hash(encodeAuthority(current)))));
    }

    public static BindingRetirementAuthorityV1 abortSourceScan(BindingRetirementAuthorityV1 current) {
        if (current.state() != BindingAuthorityStateV1.SOURCE_SCAN_FENCED_V2) {
            throw new IllegalArgumentException("Kafka source scan is not fenced");
        }
        return kafkaPolicyState(
                current, BindingAuthorityStateV1.OPEN_V1, current.kafkaPolicy().orElseThrow(), Optional.empty());
    }

    private static BindingRetirementAuthorityV1 kafkaPolicyState(
            BindingRetirementAuthorityV1 current,
            BindingAuthorityStateV1 state,
            M5KafkaBindingPolicyV1 policy,
            Optional<M5BindingAuthorityRecordsV1.BindingSourceScanFenceV2> scan) {
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                current.binding(),
                Math.addExact(current.authorityGeneration(), 1),
                Optional.of(Sha256Digest.hash(encodeAuthority(current))),
                state,
                current.selectorProjection(),
                current.batchSlots(),
                current.scanFence(),
                current.referenceMutationTickets(),
                current.writerEnrollment(),
                current.capability(),
                7,
                current.lastActivationOrdinal(),
                current.retiredHistory(),
                current.taskSelectionDecision(),
                current.materializationWorker(),
                PLACEHOLDER,
                current.logicalTrim(),
                current.trimMutationTickets(),
                current.bootstrap(),
                Optional.of(policy),
                scan));
    }

    public static BindingRetirementAuthorityV1 logicalTrimSuccessor(
            BindingRetirementAuthorityV1 current,
            M5LogicalTrimRecordsV2.LogicalTrimStateV2 trim,
            List<M5LogicalTrimRecordsV2.LogicalTrimMutationV2> mutations) {
        if (current.state() != BindingAuthorityStateV1.OPEN_V1
                && current.state() != BindingAuthorityStateV1.LOGICAL_TRIM_SCAN_FENCED_V2) {
            throw new IllegalArgumentException("retirement fence cannot become a logical trim fence");
        }
        return finalizeAuthority(new BindingRetirementAuthorityV1(
                current.binding(),
                Math.addExact(current.authorityGeneration(), 1),
                Optional.of(Sha256Digest.hash(encodeAuthority(current))),
                trim.fence().isPresent()
                        ? BindingAuthorityStateV1.LOGICAL_TRIM_SCAN_FENCED_V2
                        : BindingAuthorityStateV1.OPEN_V1,
                current.selectorProjection(),
                current.batchSlots(),
                current.scanFence(),
                current.referenceMutationTickets(),
                current.writerEnrollment(),
                current.capability(),
                Math.max(5, current.wireVersion()),
                current.lastActivationOrdinal(),
                current.retiredHistory(),
                current.taskSelectionDecision(),
                current.materializationWorker(),
                PLACEHOLDER,
                Optional.of(trim),
                mutations,
                current.bootstrap(),
                current.kafkaPolicy(),
                current.sourceScan()));
    }

    /** A trim transition changes no selector, retirement, Task or worker field. */
    public static void requireLogicalTrimTransition(
            BindingRetirementAuthorityV1 current, BindingRetirementAuthorityV1 next) {
        if (next.logicalTrim().equals(current.logicalTrim())
                && next.trimMutationTickets().equals(current.trimMutationTickets())) {
            return;
        }
        if (next.logicalTrim().isEmpty() || next.wireVersion() < 5) {
            throw new IllegalArgumentException("Binding logical trim facts cannot be discarded");
        }
        var expected = logicalTrimSuccessor(current, next.logicalTrim().orElseThrow(), next.trimMutationTickets());
        if (!encodeAuthority(expected).equals(encodeAuthority(next))) {
            throw new IllegalArgumentException("logical trim transition changed unrelated authority fields");
        }
        var oldFrontier = current.logicalTrim().flatMap(M5LogicalTrimRecordsV2.LogicalTrimStateV2::frontier);
        var newFrontier = next.logicalTrim().flatMap(M5LogicalTrimRecordsV2.LogicalTrimStateV2::frontier);
        if (!oldFrontier.equals(newFrontier) && oldFrontier.isPresent()) {
            var old = oldFrontier.orElseThrow();
            var value = newFrontier.orElseThrow(() -> new IllegalArgumentException("trim frontier cannot be removed"));
            if (value.generation() != Math.addExact(old.generation(), 1)
                    || current.state() != BindingAuthorityStateV1.LOGICAL_TRIM_SCAN_FENCED_V2) {
                throw new IllegalArgumentException("trim advancement requires its exact scan fence and generation");
            }
        }
        if (current.state() == BindingAuthorityStateV1.OPEN_V1
                && next.state() == current.state()
                && current.logicalTrim().isPresent()
                && !oldFrontier.equals(newFrontier)) {
            throw new IllegalArgumentException("ordinary writer admission cannot change the trim frontier");
        }
    }

    public static CanonicalBytes encodeAuthority(BindingRetirementAuthorityV1 value) {
        BindingRetirementAuthorityV1 placeholder = copyWithCanonicalSha(value, PLACEHOLDER);
        Sha256Digest expected = Sha256Digest.hash(encodeUnchecked(placeholder));
        if (!value.authorityCanonicalSha256().equals(expected)) {
            throw new IllegalArgumentException("Binding authority canonical SHA-256 differs");
        }
        CanonicalBytes encoded = encodeUnchecked(value);
        if (encoded.length() > M5BindingAuthorityRecordsV1.MAX_AUTHORITY_BYTES) {
            throw new IllegalArgumentException("Binding authority exceeds the metadata value hard cap");
        }
        return encoded;
    }

    public static BindingRetirementAuthorityV1 decodeAuthority(CanonicalBytes encoded) {
        BindingRetirementAuthorityV1 value = decode(encoded, input -> {
            if (input.readInt() != MAGIC) {
                throw new IllegalArgumentException("Binding authority preamble differs");
            }
            int wireVersion = input.readInt();
            if (wireVersion != 1
                    && wireVersion != VERSION
                    && wireVersion != 3
                    && wireVersion != 4
                    && wireVersion != 5
                    && wireVersion != 6
                    && wireVersion != 7) {
                throw new IllegalArgumentException("Binding authority version differs");
            }
            long generation = input.readLong();
            Optional<Sha256Digest> predecessor =
                    input.readBoolean() ? Optional.of(readDigest(input)) : Optional.empty();
            CapabilityBinding capability = readCapability(input);
            BindingReadSelector selectorCore = M4ReadControlCodecV1.decodeSelector(readBytes(input));
            int slotCount = input.readInt();
            if (slotCount < 0 || slotCount > M5BindingAuthorityRecordsV1.MAX_BATCH_SLOTS) {
                throw new IllegalArgumentException("Binding authority batch-slot count exceeds its hard cap");
            }
            List<BatchAuthoritySlotV1> slots = new ArrayList<>();
            for (int index = 0; index < slotCount; index++) {
                long ordinal = input.readLong();
                BatchMetadataStateV1 state =
                        enumValue(BatchMetadataStateV1.values(), input.readUnsignedByte(), "batch-slot state");
                Sha256Digest batchId = readDigest(input);
                Sha256Digest fullSha = readDigest(input);
                if (state == BatchMetadataStateV1.FULL_V1) {
                    slots.add(new BatchAuthoritySlotV1(
                            ordinal, state, batchId, fullSha, Optional.of(readBytes(input)), Optional.empty()));
                } else {
                    slots.add(new BatchAuthoritySlotV1(
                            ordinal,
                            state,
                            batchId,
                            fullSha,
                            Optional.empty(),
                            Optional.of(M5RetentionCodecV1.decodeRetiredBatch(readBytes(input)))));
                }
            }
            BindingReadSelector projection = withActiveBatches(
                    selectorCore,
                    slots.stream()
                            .filter(slot -> slot.state() == BatchMetadataStateV1.FULL_V1)
                            .map(BatchAuthoritySlotV1::fullBatch)
                            .toList());
            Optional<ReferenceScanFenceV1> fence = input.readBoolean()
                    ? Optional.of(new ReferenceScanFenceV1(
                            enumValue(
                                    ReferenceTargetKindV1.values(), input.readUnsignedByte(), "scan-fence target kind"),
                            readDigest(input),
                            readDigest(input),
                            readDigest(input)))
                    : Optional.empty();
            int ticketCount = input.readInt();
            if (ticketCount < 0 || ticketCount > M5BindingAuthorityRecordsV1.MAX_REFERENCE_MUTATION_TICKETS) {
                throw new IllegalArgumentException("Binding authority ticket count exceeds its hard cap");
            }
            List<ReferenceMutationTicketV1> tickets = new ArrayList<>();
            for (int index = 0; index < ticketCount; index++) {
                tickets.add(new ReferenceMutationTicketV1(
                        enumValue(ReferenceTargetKindV1.values(), input.readUnsignedByte(), "ticket target kind"),
                        readDigest(input),
                        enumValue(ReferenceKindV1.values(), input.readUnsignedByte(), "ticket reference kind"),
                        readCapability(input),
                        readDigest(input),
                        readDigest(input)));
            }
            Optional<ReferenceWriterEnrollmentV1> enrollment;
            if (input.readBoolean()) {
                CapabilityBinding enrollmentCapability = readCapability(input);
                int floorCount = input.readInt();
                if (floorCount < 0 || floorCount > FloorClassV1.values().length) {
                    throw new IllegalArgumentException("writer-enrollment floor count differs");
                }
                List<FloorClassV1> floors = new ArrayList<>();
                for (int index = 0; index < floorCount; index++) {
                    floors.add(enumValue(FloorClassV1.values(), input.readUnsignedByte(), "enrolled floor class"));
                }
                int referenceCount = input.readInt();
                if (referenceCount < 0 || referenceCount > ReferenceKindV1.values().length) {
                    throw new IllegalArgumentException("writer-enrollment reference count differs");
                }
                List<ReferenceKindV1> references = new ArrayList<>();
                for (int index = 0; index < referenceCount; index++) {
                    references.add(
                            enumValue(ReferenceKindV1.values(), input.readUnsignedByte(), "enrolled reference kind"));
                }
                enrollment = Optional.of(
                        new ReferenceWriterEnrollmentV1(enrollmentCapability, floors, references, readDigest(input)));
            } else {
                enrollment = Optional.empty();
            }
            BindingAuthorityStateV1 authorityState =
                    enumValue(BindingAuthorityStateV1.values(), input.readUnsignedByte(), "Binding authority state");
            long lastOrdinal = wireVersion == 1 ? slots.size() : input.readLong();
            var history = wireVersion == 1
                    ? M5RetiredBatchHistoryV2.emptyRoot(projection.binding())
                    : new M5RetiredBatchHistoryV2.Root(readDigest(input), input.readLong());
            Optional<M5TaskSelectionDecisionV2> decision = Optional.empty();
            if (wireVersion >= 3) {
                int present = input.readUnsignedByte();
                if (present > 1) {
                    throw new IllegalArgumentException("task selection anchor presence is not canonical");
                }
                if (present == 1) {
                    decision = Optional.of(M5TaskSelectionDecisionV2.decode(readBytes(input)));
                }
            }
            Optional<M5MaterializationWorkerV1> worker = Optional.empty();
            if (wireVersion >= 4) {
                int present = input.readUnsignedByte();
                if (present > 1) {
                    throw new IllegalArgumentException("worker grant presence is not canonical");
                }
                if (present == 1) {
                    worker = Optional.of(M5MaterializationWorkerV1.decode(readBytes(input)));
                }
            }
            Optional<M5LogicalTrimRecordsV2.LogicalTrimStateV2> trim = Optional.empty();
            List<M5LogicalTrimRecordsV2.LogicalTrimMutationV2> trimMutations = new ArrayList<>();
            if (wireVersion == 5 || wireVersion >= 6 && input.readBoolean()) {
                trim = Optional.of(M5LogicalTrimCodecV2.readState(input));
                int count = input.readInt();
                if (count < 0 || count > M5LogicalTrimRecordsV2.MAX_MUTATIONS) {
                    throw new IllegalArgumentException("trim mutation count exceeds its bound");
                }
                for (int i = 0; i < count; i++) {
                    trimMutations.add(M5LogicalTrimCodecV2.readMutation(input));
                }
            }
            Optional<M5BindingBootstrapV1> bootstrap =
                    wireVersion >= 6 ? Optional.of(M5BindingBootstrapV1.decode(readBytes(input))) : Optional.empty();
            Optional<M5KafkaBindingPolicyV1> kafkaPolicy =
                    wireVersion >= 7 ? Optional.of(M5KafkaBindingPolicyV1.decode(readBytes(input))) : Optional.empty();
            Optional<M5BindingAuthorityRecordsV1.BindingSourceScanFenceV2> sourceScan = Optional.empty();
            if (wireVersion >= 7 && input.readBoolean()) {
                sourceScan = Optional.of(
                        new M5BindingAuthorityRecordsV1.BindingSourceScanFenceV2(readDigest(input), readDigest(input)));
            }
            Sha256Digest canonicalSha = readDigest(input);
            return new BindingRetirementAuthorityV1(
                    projection.binding(),
                    generation,
                    predecessor,
                    authorityState,
                    projection,
                    slots,
                    fence,
                    tickets,
                    enrollment,
                    capability,
                    wireVersion,
                    lastOrdinal,
                    history,
                    decision,
                    worker,
                    canonicalSha,
                    trim,
                    trimMutations,
                    bootstrap,
                    kafkaPolicy,
                    sourceScan);
        });
        if (!Arrays.equals(encoded.toByteArray(), encodeAuthority(value).toByteArray())) {
            throw new IllegalArgumentException("Binding authority value is not canonical");
        }
        return value;
    }

    public static BindingReadSelector projectSelector(CanonicalBytes stored) {
        return isAuthorityValue(stored)
                ? decodeAuthority(stored).selectorProjection()
                : M4ReadControlCodecV1.decodeSelector(stored);
    }

    private static BindingRetirementAuthorityV1 finalizeAuthority(BindingRetirementAuthorityV1 draft) {
        BindingRetirementAuthorityV1 placeholder = copyWithCanonicalSha(draft, PLACEHOLDER);
        return copyWithCanonicalSha(draft, Sha256Digest.hash(encodeUnchecked(placeholder)));
    }

    private static BindingRetirementAuthorityV1 copyWithCanonicalSha(
            BindingRetirementAuthorityV1 value, Sha256Digest canonicalSha) {
        return new BindingRetirementAuthorityV1(
                value.binding(),
                value.authorityGeneration(),
                value.predecessorValueSha256(),
                value.state(),
                value.selectorProjection(),
                value.batchSlots(),
                value.scanFence(),
                value.referenceMutationTickets(),
                value.writerEnrollment(),
                value.capability(),
                value.wireVersion(),
                value.lastActivationOrdinal(),
                value.retiredHistory(),
                value.taskSelectionDecision(),
                value.materializationWorker(),
                canonicalSha,
                value.logicalTrim(),
                value.trimMutationTickets(),
                value.bootstrap(),
                value.kafkaPolicy(),
                value.sourceScan());
    }

    private static CanonicalBytes encodeUnchecked(BindingRetirementAuthorityV1 value) {
        return encode(out -> {
            out.writeInt(MAGIC);
            out.writeInt(value.wireVersion());
            out.writeLong(value.authorityGeneration());
            out.writeBoolean(value.predecessorValueSha256().isPresent());
            if (value.predecessorValueSha256().isPresent()) {
                writeDigest(out, value.predecessorValueSha256().orElseThrow());
            }
            writeCapability(out, value.capability());
            writeBytes(
                    out,
                    M4ReadControlCodecV1.encodeSelector(
                            M5BindingAuthorityRecordsV1.withoutActiveBatches(value.selectorProjection())));
            out.writeInt(value.batchSlots().size());
            for (BatchAuthoritySlotV1 slot : value.batchSlots()) {
                out.writeLong(slot.activationOrdinal());
                out.writeByte(slot.state().ordinal());
                writeDigest(out, slot.batchIdSha256());
                writeDigest(out, slot.fullBatchSha256());
                if (slot.state() == BatchMetadataStateV1.FULL_V1) {
                    writeBytes(out, slot.canonicalM4BatchBytes().orElseThrow());
                } else {
                    writeBytes(
                            out,
                            M5RetentionCodecV1.encodeRetiredBatch(
                                    slot.retiredTombstone().orElseThrow()));
                }
            }
            out.writeBoolean(value.scanFence().isPresent());
            if (value.scanFence().isPresent()) {
                ReferenceScanFenceV1 fence = value.scanFence().orElseThrow();
                out.writeByte(fence.targetKind().ordinal());
                writeDigest(out, fence.targetIdentitySha256());
                writeDigest(out, fence.attemptIdSha256());
                writeDigest(out, fence.openAuthorityValueSha256());
            }
            out.writeInt(value.referenceMutationTickets().size());
            for (ReferenceMutationTicketV1 ticket : value.referenceMutationTickets()) {
                out.writeByte(ticket.targetKind().ordinal());
                writeDigest(out, ticket.targetIdentitySha256());
                out.writeByte(ticket.referenceKind().ordinal());
                writeCapability(out, ticket.writerCapability());
                writeDigest(out, ticket.operationIdSha256());
                writeDigest(out, ticket.externalAuthorityRootSha256());
            }
            out.writeBoolean(value.writerEnrollment().isPresent());
            if (value.writerEnrollment().isPresent()) {
                ReferenceWriterEnrollmentV1 enrollment =
                        value.writerEnrollment().orElseThrow();
                writeCapability(out, enrollment.capability());
                out.writeInt(enrollment.floorClasses().size());
                for (FloorClassV1 floor : enrollment.floorClasses()) {
                    out.writeByte(floor.ordinal());
                }
                out.writeInt(enrollment.referenceKinds().size());
                for (ReferenceKindV1 reference : enrollment.referenceKinds()) {
                    out.writeByte(reference.ordinal());
                }
                writeDigest(out, enrollment.implementationRootSha256());
            }
            out.writeByte(value.state().ordinal());
            if (value.wireVersion() >= 2) {
                out.writeLong(value.lastActivationOrdinal());
                writeDigest(out, value.retiredHistory().sha256());
                out.writeLong(value.retiredHistory().count());
            }
            if (value.wireVersion() >= 3) {
                out.writeByte(value.taskSelectionDecision().isPresent() ? 1 : 0);
                if (value.taskSelectionDecision().isPresent()) {
                    writeBytes(out, value.taskSelectionDecision().orElseThrow().encode());
                }
            }
            if (value.wireVersion() >= 4) {
                out.writeByte(value.materializationWorker().isPresent() ? 1 : 0);
                if (value.materializationWorker().isPresent()) {
                    writeBytes(out, value.materializationWorker().orElseThrow().encode());
                }
            }
            if (value.wireVersion() >= 6) {
                out.writeBoolean(value.logicalTrim().isPresent());
            }
            if (value.logicalTrim().isPresent()) {
                M5LogicalTrimCodecV2.writeState(out, value.logicalTrim().orElseThrow());
                out.writeInt(value.trimMutationTickets().size());
                for (var mutation : value.trimMutationTickets()) {
                    M5LogicalTrimCodecV2.writeMutation(out, mutation);
                }
            }
            if (value.wireVersion() >= 6) {
                writeBytes(out, value.bootstrap().orElseThrow().encode());
            }
            if (value.wireVersion() >= 7) {
                writeBytes(out, value.kafkaPolicy().orElseThrow().encode());
                out.writeBoolean(value.sourceScan().isPresent());
                if (value.sourceScan().isPresent()) {
                    writeDigest(out, value.sourceScan().orElseThrow().attemptId());
                    writeDigest(out, value.sourceScan().orElseThrow().openAuthoritySha256());
                }
            }
            writeDigest(out, value.authorityCanonicalSha256());
        });
    }

    private static List<BatchAuthoritySlotV1> fullSlots(List<SourceRetirementBatch> batches) {
        List<BatchAuthoritySlotV1> slots = new ArrayList<>();
        long ordinal = 0;
        for (SourceRetirementBatch batch : batches) {
            slots.add(BatchAuthoritySlotV1.full(++ordinal, batch));
        }
        return slots;
    }

    private static BindingReadSelector withActiveBatches(
            BindingReadSelector core, List<SourceRetirementBatch> batches) {
        return new BindingReadSelector(
                core.binding(),
                core.selectedViewSha256(),
                core.ownerEpoch(),
                core.readAdmissionEpoch(),
                core.sourceGeneration(),
                core.mode(),
                core.admissionState(),
                core.fallbackSetSha256(),
                core.capability(),
                core.pendingAnchors(),
                batches);
    }

    private static void writeCapability(DataOutputStream output, CapabilityBinding capability) throws IOException {
        output.writeLong(capability.generation());
        writeDigest(output, capability.evidenceSha256());
    }

    private static CapabilityBinding readCapability(DataInputStream input) throws IOException {
        return new CapabilityBinding(input.readLong(), readDigest(input));
    }

    private static void writeDigest(DataOutputStream output, Sha256Digest digest) throws IOException {
        output.write(digest.bytes().toByteArray());
    }

    private static Sha256Digest readDigest(DataInputStream input) throws IOException {
        return Sha256Digest.copyOf(input.readNBytes(Sha256Digest.LENGTH));
    }

    private static void writeBytes(DataOutputStream output, CanonicalBytes bytes) throws IOException {
        if (bytes.isEmpty() || bytes.length() > M5BindingAuthorityRecordsV1.MAX_AUTHORITY_BYTES) {
            throw new IllegalArgumentException("nested Binding authority bytes exceed their hard cap");
        }
        output.writeInt(bytes.length());
        output.write(bytes.toByteArray());
    }

    private static CanonicalBytes readBytes(DataInputStream input) throws IOException {
        int length = input.readInt();
        if (length <= 0 || length > M5BindingAuthorityRecordsV1.MAX_AUTHORITY_BYTES) {
            throw new IllegalArgumentException("nested Binding authority byte length exceeds its hard cap");
        }
        byte[] value = input.readNBytes(length);
        if (value.length != length) {
            throw new EOFException("truncated nested Binding authority bytes");
        }
        return CanonicalBytes.copyOf(value);
    }

    private static <T> T enumValue(T[] values, int ordinal, String label) {
        if (ordinal < 0 || ordinal >= values.length) {
            throw new IllegalArgumentException(label + " ordinal is unknown");
        }
        return values[ordinal];
    }

    private static CanonicalBytes encode(Writer writer) {
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (DataOutputStream output = new DataOutputStream(buffer)) {
                writer.write(output);
            }
            return CanonicalBytes.copyOf(buffer.toByteArray());
        } catch (IOException error) {
            throw new IllegalStateException("cannot encode Binding authority", error);
        }
    }

    private static <T> T decode(CanonicalBytes encoded, Reader<T> reader) {
        if (encoded.isEmpty() || encoded.length() > M5BindingAuthorityRecordsV1.MAX_AUTHORITY_BYTES) {
            throw new IllegalArgumentException("Binding authority bytes exceed their hard cap");
        }
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(encoded.toByteArray()))) {
            T value = reader.read(input);
            if (input.read() != -1) {
                throw new IllegalArgumentException("Binding authority contains trailing bytes");
            }
            return value;
        } catch (IOException error) {
            throw new IllegalArgumentException("cannot decode Binding authority", error);
        }
    }

    @FunctionalInterface
    private interface Writer {
        void write(DataOutputStream output) throws IOException;
    }

    @FunctionalInterface
    private interface Reader<T> {
        T read(DataInputStream input) throws IOException;
    }
}
