/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.storage.object.gc;

import com.nereusstream.domain.bytes.Sha256Digest;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.DeleteTerminalOutcomeV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.ExactExternalIdentityV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.ExternalIdentityObservationV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.PhysicalDeleteTargetV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.ProofBoundWriterEnrollmentV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.ProofBoundWriterTicketV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.TargetDeleteAuthorityStateV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.TargetDeleteAuthorityV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.TargetDeleteDoneV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.TargetDeleteIntentV1;
import com.nereusstream.storage.object.gc.M5TargetDeleteAuthorityRecordsV1.TargetReadFenceV1;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** Pure candidate construction for the irreversible one-target M5-D authority state machine. */
public final class M5TargetDeleteAuthorityStateMachineV1 {
    private M5TargetDeleteAuthorityStateMachineV1() {}

    public static TargetDeleteAuthorityV1 open(
            PhysicalDeleteTargetV1 target,
            ProofBoundWriterEnrollmentV1 writerEnrollment,
            Sha256Digest proofSnapshotDigest) {
        return initial(target, writerEnrollment, proofSnapshotDigest, Optional.empty());
    }

    public static TargetDeleteAuthorityV1 open(
            PhysicalDeleteTargetV1 target,
            ProofBoundWriterEnrollmentV1 writerEnrollment,
            DeleteEligibilitySnapshotV2 snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        snapshot.requireCanonicalM4ReleaseKeys();
        if (snapshot.generation() != 1) {
            throw new IllegalArgumentException("initial eligibility must bind authority revision one");
        }
        return initial(target, writerEnrollment, snapshot.sha256(), Optional.of(snapshot));
    }

    private static TargetDeleteAuthorityV1 initial(
            PhysicalDeleteTargetV1 target,
            ProofBoundWriterEnrollmentV1 writerEnrollment,
            Sha256Digest proofSnapshotDigest,
            Optional<DeleteEligibilitySnapshotV2> snapshot) {
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(writerEnrollment, "writerEnrollment");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(proofSnapshotDigest, "proofSnapshotDigest");
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                M5TargetDeleteAuthorityKeysV1.authorityKey(target),
                target,
                1,
                Optional.empty(),
                TargetDeleteAuthorityStateV1.OPEN_V1,
                0,
                writerEnrollment,
                proofSnapshotDigest,
                snapshot,
                List.of(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                zeroDigest()));
    }

    /** A clock mark does not qualify eligibility; a subsequent native producer must complete its full rescan. */
    public static TargetDeleteAuthorityV1 markEpochGrace(TargetDeleteAuthorityV1 current, DeleteEpochGraceMarkV1 mark) {
        requireOpen(current);
        Objects.requireNonNull(mark, "mark");
        if (!current.activeWriterTickets().isEmpty()) {
            throw new IllegalStateException("epoch grace cannot start with active resource writers");
        }
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                current.authorityKey(),
                current.target(),
                Math.addExact(current.authorityRevision(), 1),
                Optional.of(Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current))),
                TargetDeleteAuthorityStateV1.OPEN_V1,
                0,
                current.writerEnrollment(),
                mark.initialObservationRootSha256(),
                Optional.empty(),
                List.of(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.of(mark),
                zeroDigest()));
    }

    /** Rewait under a new clock while preserving the closed read attempt and its historical qualification. */
    public static TargetDeleteAuthorityV1 renewReadEpochGrace(
            TargetDeleteAuthorityV1 current, DeleteEpochGraceMarkV1 mark) {
        requireState(current, TargetDeleteAuthorityStateV1.READ_FENCED_V1);
        if (current.epochGrace().isEmpty()) {
            throw new IllegalArgumentException("read grace renewal requires an existing epoch profile");
        }
        var previous = current.readFence().orElseThrow().observationContext();
        var successor = mark.authority();
        if (successor.observationEpoch() != Math.addExact(previous.observationEpoch(), 1)
                || (!previous.coordinatorOwner().equals(successor.coordinatorOwner()))
                        != successor.predecessorOwnerFenced().isPresent()
                || current.epochGrace().orElseThrow().clockDomain().equals(mark.clockDomain())) {
            throw new IllegalArgumentException("read grace renewal has a reused clock or stale/unfenced context");
        }
        return recoveryVetoAuthority(
                current, DeleteRecoveryVetoV2.Reason.EPOCH_GRACE_RENEWAL_PENDING, successor, Optional.of(mark));
    }

    /** Retains the original intent/identity while a successor owner reconfirms and waits its own grace. */
    public static TargetDeleteAuthorityV1 renewIntentEpochGrace(
            TargetDeleteAuthorityV1 current, DeleteEpochGraceMarkV1 mark) {
        requireState(current, TargetDeleteAuthorityStateV1.DELETE_INTENT_V1);
        if (current.epochGrace().isEmpty()) {
            throw new IllegalArgumentException("intent grace renewal requires an existing epoch profile");
        }
        var previous = dispatchContext(current);
        var successor = mark.authority();
        if (previous.coordinatorOwner().equals(successor.coordinatorOwner())) {
            throw new IllegalArgumentException("intent renewal requires a fenced successor native owner");
        }
        if (successor.observationEpoch() != Math.addExact(previous.observationEpoch(), 1)
                || (!previous.coordinatorOwner().equals(successor.coordinatorOwner()))
                        != successor.predecessorOwnerFenced().isPresent()
                || current.epochGrace().orElseThrow().clockDomain().equals(mark.clockDomain())) {
            throw new IllegalArgumentException("intent grace renewal has a reused clock or stale/unfenced context");
        }
        return recoveryVetoAuthority(
                current, DeleteRecoveryVetoV2.Reason.EPOCH_GRACE_RENEWAL_PENDING, successor, Optional.of(mark));
    }

    /** Installs complete evidence at one exact revision; callers must revalidate its external authority vector. */
    public static TargetDeleteAuthorityV1 qualifyEligibility(
            TargetDeleteAuthorityV1 current, DeleteEligibilitySnapshotV2 snapshot) {
        requireOpen(current);
        Objects.requireNonNull(snapshot, "snapshot");
        snapshot.requireCanonicalM4ReleaseKeys();
        if (!current.activeWriterTickets().isEmpty()
                || snapshot.generation() != Math.addExact(current.authorityRevision(), 1)
                || !snapshot.resource().equals(current.target().resourceId())) {
            throw new IllegalArgumentException(
                    "eligibility qualification has writers or a stale/foreign revision/resource");
        }
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                current.authorityKey(),
                current.target(),
                snapshot.generation(),
                Optional.of(Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current))),
                TargetDeleteAuthorityStateV1.OPEN_V1,
                0,
                current.writerEnrollment(),
                snapshot.sha256(),
                Optional.of(snapshot),
                List.of(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                current.epochGrace(),
                zeroDigest()));
    }

    public static TargetDeleteAuthorityV1 acquireWriterTicket(
            TargetDeleteAuthorityV1 current, ProofBoundWriterTicketV1 ticket) {
        requireOpen(current);
        Objects.requireNonNull(ticket, "ticket");
        if (ticket.predecessorAuthorityRevision() != current.authorityRevision()) {
            throw new IllegalArgumentException("writer ticket does not bind the exact predecessor revision");
        }
        ArrayList<ProofBoundWriterTicketV1> tickets = new ArrayList<>(current.activeWriterTickets());
        if (tickets.stream().anyMatch(value -> value.operationIdSha256().equals(ticket.operationIdSha256()))) {
            throw new IllegalArgumentException("writer operation already has one active ticket");
        }
        tickets.add(ticket);
        tickets.sort(Comparator.comparing(ProofBoundWriterTicketV1::writerClass)
                .thenComparing(value -> value.operationIdSha256().toHex()));
        return openSuccessor(current, current.proofSnapshotDigest(), tickets);
    }

    public static TargetDeleteAuthorityV1 completeWriterTicket(
            TargetDeleteAuthorityV1 current,
            Sha256Digest operationIdSha256,
            Sha256Digest reconciledProofSnapshotDigest) {
        requireOpen(current);
        M5TargetDeleteAuthorityRecordsV1.requireDigest(operationIdSha256, "operationIdSha256");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(reconciledProofSnapshotDigest, "reconciledProofSnapshotDigest");
        List<ProofBoundWriterTicketV1> tickets = current.activeWriterTickets().stream()
                .filter(value -> !value.operationIdSha256().equals(operationIdSha256))
                .toList();
        if (tickets.size() == current.activeWriterTickets().size()) {
            throw new IllegalArgumentException("writer operation has no active ticket to reconcile");
        }
        return openSuccessor(current, reconciledProofSnapshotDigest, tickets);
    }

    /** CAS-1 candidate: closes every writer and grants no external dispatch authority. */
    public static TargetDeleteAuthorityV1 prepareIdentityRead(
            TargetDeleteAuthorityV1 current, Sha256Digest attemptIdSha256, DeleteObservationContextV2 context) {
        requireOpen(current);
        Objects.requireNonNull(context, "context");
        if (current.epochGrace().isPresent()) {
            var mark = current.epochGrace().orElseThrow();
            if (!context.equals(mark.authority())
                    || current.eligibilitySnapshot().isEmpty()
                    || current.eligibilitySnapshot().orElseThrow().members().stream()
                            .anyMatch(member ->
                                    !member.physicalReferences().epochGrace().equals(Optional.of(mark)))) {
                throw new IllegalArgumentException("CAS-1 lacks the current epoch mark and complete rescan proof");
            }
        } else if (context.observationEpoch() != 1
                || context.predecessorOwnerFenced().isPresent()) {
            throw new IllegalArgumentException("CAS-1 requires initial observation epoch without a predecessor");
        }
        M5TargetDeleteAuthorityRecordsV1.requireDigest(attemptIdSha256, "attemptIdSha256");
        if (!current.activeWriterTickets().isEmpty()) {
            throw new IllegalStateException("active or unresolved writer ticket vetoes CAS-1");
        }
        DeleteEligibilitySnapshotV2 snapshot = current.eligibilitySnapshot()
                .orElseThrow(() -> new IllegalStateException("CAS-1 requires a complete typed eligibility snapshot"));
        Sha256Digest eligibilityRootSha256 = snapshot.sha256();
        long fencedRevision = Math.addExact(current.authorityRevision(), 1);
        long fenceEpoch = Math.addExact(current.closedWriterFenceEpoch(), 1);
        TargetReadFenceV1 fence = new TargetReadFenceV1(
                attemptIdSha256,
                fencedRevision,
                fenceEpoch,
                Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current)),
                current.proofSnapshotDigest(),
                eligibilityRootSha256,
                context);
        return M5TargetDeleteAuthorityCodecV1.successor(
                current,
                TargetDeleteAuthorityStateV1.READ_FENCED_V1,
                fenceEpoch,
                current.proofSnapshotDigest(),
                List.of(),
                Optional.of(fence),
                Optional.empty(),
                Optional.empty(),
                Optional.empty());
    }

    /** Keeps admission closed while replacing all observation evidence at one exact successor revision. */
    public static TargetDeleteAuthorityV1 refreshIdentityRead(
            TargetDeleteAuthorityV1 current,
            DeleteObservationContextV2 successor,
            DeleteEligibilitySnapshotV2 snapshot) {
        requireState(current, TargetDeleteAuthorityStateV1.READ_FENCED_V1);
        Objects.requireNonNull(successor, "successor");
        Objects.requireNonNull(snapshot, "snapshot");
        TargetReadFenceV1 previous = current.readFence().orElseThrow();
        DeleteObservationContextV2 previousContext = previous.observationContext();
        boolean ownerChanged = !previousContext.coordinatorOwner().equals(successor.coordinatorOwner());
        long revision = Math.addExact(current.authorityRevision(), 1);
        if (successor.observationEpoch() != Math.addExact(previousContext.observationEpoch(), 1)
                || ownerChanged != successor.predecessorOwnerFenced().isPresent()
                || snapshot.generation() != revision
                || !snapshot.resource().equals(current.target().resourceId())) {
            throw new IllegalArgumentException(
                    "read refresh has a stale epoch/revision/resource or lacks owner fencing");
        }
        TargetReadFenceV1 fence = new TargetReadFenceV1(
                previous.attemptIdSha256(),
                revision,
                previous.fenceEpoch(),
                previous.openAuthorityValueSha256(),
                snapshot.sha256(),
                snapshot.sha256(),
                successor);
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                current.authorityKey(),
                current.target(),
                revision,
                Optional.of(Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current))),
                TargetDeleteAuthorityStateV1.READ_FENCED_V1,
                current.closedWriterFenceEpoch(),
                current.writerEnrollment(),
                snapshot.sha256(),
                Optional.of(snapshot),
                List.of(),
                Optional.of(fence),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                current.epochGrace(),
                zeroDigest()));
    }

    /** Persists one visible veto without reopening admission or changing the physical target/read attempt. */
    public static TargetDeleteAuthorityV1 recordRecoveryVeto(
            TargetDeleteAuthorityV1 current,
            DeleteRecoveryVetoV2.Reason reason,
            DeleteObservationContextV2 rejectedContext) {
        requireState(current, TargetDeleteAuthorityStateV1.READ_FENCED_V1);
        Objects.requireNonNull(rejectedContext, "rejectedContext");
        if (current.recoveryVeto()
                .filter(veto -> veto.reason() == DeleteRecoveryVetoV2.Reason.EPOCH_GRACE_RENEWAL_PENDING)
                .isPresent()) {
            reason = DeleteRecoveryVetoV2.Reason.EPOCH_GRACE_RENEWAL_PENDING;
            rejectedContext = current.epochGrace().orElseThrow().authority();
        }
        return recoveryVetoAuthority(current, reason, rejectedContext, current.epochGrace());
    }

    private static TargetDeleteAuthorityV1 recoveryVetoAuthority(
            TargetDeleteAuthorityV1 current,
            DeleteRecoveryVetoV2.Reason reason,
            DeleteObservationContextV2 rejectedContext,
            Optional<DeleteEpochGraceMarkV1> mark) {
        long revision = Math.addExact(current.authorityRevision(), 1);
        var previous = current.readFence().orElseThrow();
        var predecessorSha = Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current));
        var veto = new DeleteRecoveryVetoV2(
                reason,
                rejectedContext.observationEpoch(),
                M5TargetDeleteAuthorityCodecV1.observationContextSha256(rejectedContext),
                predecessorSha);
        var fence = current.state() == TargetDeleteAuthorityStateV1.DELETE_INTENT_V1
                ? previous
                : new TargetReadFenceV1(
                        previous.attemptIdSha256(),
                        revision,
                        previous.fenceEpoch(),
                        previous.openAuthorityValueSha256(),
                        previous.proofSnapshotDigest(),
                        previous.eligibilityRootSha256(),
                        previous.observationContext());
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                current.authorityKey(),
                current.target(),
                revision,
                Optional.of(predecessorSha),
                current.state(),
                current.closedWriterFenceEpoch(),
                current.writerEnrollment(),
                current.proofSnapshotDigest(),
                current.eligibilitySnapshot(),
                List.of(),
                Optional.of(fence),
                current.externalIdentity(),
                current.deleteIntent(),
                Optional.empty(),
                Optional.of(veto),
                mark,
                zeroDigest()));
    }

    /** CAS-2 candidate: binds one exact observation, fixed attempt, owner fence, and dispatch token. */
    public static TargetDeleteAuthorityV1 bindDeleteIntent(
            TargetDeleteAuthorityV1 current,
            ExactExternalIdentityV1 externalIdentity,
            Sha256Digest deleteAttemptIdSha256) {
        requireState(current, TargetDeleteAuthorityStateV1.READ_FENCED_V1);
        if (current.recoveryVeto().isPresent()) {
            throw new IllegalStateException("recovery veto requires a qualified observation refresh before intent");
        }
        Objects.requireNonNull(externalIdentity, "externalIdentity");
        if (!externalIdentity.resourceId().equals(current.target().resourceId())
                || !externalIdentity
                        .fencedAuthoritySha256()
                        .equals(Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current)))) {
            throw new IllegalArgumentException("external identity belongs to another resource or observation epoch");
        }
        DeleteObservationContextV2 context = current.readFence().orElseThrow().observationContext();
        Sha256Digest dispatchOwnerFenceSha256 = context.coordinatorOwner().valueSha256();
        Sha256Digest capabilityDigestSha256 = context.capability().valueSha256();
        M5TargetDeleteAuthorityRecordsV1.requireDigest(deleteAttemptIdSha256, "deleteAttemptIdSha256");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(dispatchOwnerFenceSha256, "dispatchOwnerFenceSha256");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(capabilityDigestSha256, "capabilityDigestSha256");
        long intentRevision = Math.addExact(current.authorityRevision(), 1);
        long dispatchEpoch = 1;
        TargetDeleteIntentV1 intent = new TargetDeleteIntentV1(
                deleteAttemptIdSha256,
                intentRevision,
                dispatchEpoch,
                dispatchOwnerFenceSha256,
                Optional.empty(),
                capabilityDigestSha256,
                M5TargetDeleteAuthorityKeysV1.dispatchTokenSha256(
                        current.authorityKey(),
                        current.target().targetIdentitySha256(),
                        intentRevision,
                        deleteAttemptIdSha256,
                        dispatchEpoch,
                        dispatchOwnerFenceSha256,
                        externalIdentity.externalIdentitySha256()));
        return M5TargetDeleteAuthorityCodecV1.successor(
                current,
                TargetDeleteAuthorityStateV1.DELETE_INTENT_V1,
                current.closedWriterFenceEpoch(),
                current.proofSnapshotDigest(),
                List.of(),
                current.readFence(),
                Optional.of(externalIdentity),
                Optional.of(intent),
                Optional.empty());
    }

    /** Resolves only persisted typed context; a legacy hash-only takeover cannot establish native ownership. */
    public static DeleteObservationContextV2 dispatchContext(TargetDeleteAuthorityV1 current) {
        requireState(current, TargetDeleteAuthorityStateV1.DELETE_INTENT_V1);
        TargetDeleteIntentV1 intent = current.deleteIntent().orElseThrow();
        if (intent.dispatchRefresh().isPresent()) {
            return intent.dispatchRefresh().orElseThrow().current();
        }
        DeleteObservationContextV2 original = current.readFence().orElseThrow().observationContext();
        if (intent.dispatchEpoch() != 1
                || !intent.dispatchOwnerFenceSha256()
                        .equals(original.coordinatorOwner().valueSha256())
                || !intent.capabilityDigestSha256().equals(original.capability().valueSha256())) {
            throw new IllegalStateException("legacy dispatch takeover has no verifiable typed owner context");
        }
        return original;
    }

    static ExternalIdentityObservationV1 dispatchObservation(TargetDeleteAuthorityV1 current) {
        return current.deleteIntent()
                .orElseThrow()
                .dispatchRefresh()
                .map(DeleteDispatchRefreshV2::externalObservation)
                .orElseGet(() -> current.externalIdentity().orElseThrow().observation());
    }

    /** Pure candidate construction; the coordinator must verify native authorities and re-read the identity. */
    public static TargetDeleteAuthorityV1 refreshDispatch(
            TargetDeleteAuthorityV1 current,
            DeleteObservationContextV2 successor,
            DeleteEligibilitySnapshotV2 snapshot,
            ExternalIdentityObservationV1 observation) {
        DeleteObservationContextV2 previousContext = dispatchContext(current);
        if (dispatchObservation(current) == ExternalIdentityObservationV1.ABSENT_EXACT_V1
                && observation != ExternalIdentityObservationV1.ABSENT_EXACT_V1) {
            throw new IllegalStateException("authoritatively absent immutable target cannot reappear during refresh");
        }
        Objects.requireNonNull(snapshot, "snapshot");
        long revision = Math.addExact(current.authorityRevision(), 1);
        if (snapshot.generation() != revision
                || !snapshot.resource().equals(current.target().resourceId())) {
            throw new IllegalArgumentException("dispatch refresh requires complete fresh same-resource eligibility");
        }
        TargetDeleteIntentV1 previous = current.deleteIntent().orElseThrow();
        Sha256Digest predecessor = Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current));
        var refresh = new DeleteDispatchRefreshV2(
                current.authorityRevision(),
                predecessor,
                previous.dispatchEpoch(),
                previousContext,
                successor,
                observation);
        long epoch = Math.addExact(previous.dispatchEpoch(), 1);
        Sha256Digest owner = successor.coordinatorOwner().valueSha256();
        Sha256Digest capability = successor.capability().valueSha256();
        Sha256Digest baseToken = M5TargetDeleteAuthorityKeysV1.dispatchTokenSha256(
                current.authorityKey(),
                current.target().targetIdentitySha256(),
                previous.intentAuthorityRevision(),
                previous.deleteAttemptIdSha256(),
                epoch,
                owner,
                current.externalIdentity().orElseThrow().externalIdentitySha256());
        var intent = new TargetDeleteIntentV1(
                previous.deleteAttemptIdSha256(),
                previous.intentAuthorityRevision(),
                epoch,
                owner,
                successor.predecessorOwnerFenced().map(value -> value.valueSha256()),
                capability,
                M5TargetDeleteAuthorityKeysV1.refreshedDispatchTokenSha256(
                        baseToken, capability, snapshot.sha256(), refresh.sha256()),
                Optional.of(refresh));
        return M5TargetDeleteAuthorityCodecV1.finalizeAuthority(new TargetDeleteAuthorityV1(
                current.authorityKey(),
                current.target(),
                revision,
                Optional.of(predecessor),
                TargetDeleteAuthorityStateV1.DELETE_INTENT_V1,
                current.closedWriterFenceEpoch(),
                current.writerEnrollment(),
                snapshot.sha256(),
                Optional.of(snapshot),
                List.of(),
                current.readFence(),
                current.externalIdentity(),
                Optional.of(intent),
                Optional.empty(),
                Optional.empty(),
                current.epochGrace(),
                Sha256Digest.copyOf(new byte[Sha256Digest.LENGTH])));
    }

    /** Legacy pure wire4 candidate builder; it does not perform native verification or grant dispatch authority. */
    public static TargetDeleteAuthorityV1 takeOverDispatch(
            TargetDeleteAuthorityV1 current,
            long nextDispatchEpoch,
            Sha256Digest nextDispatchOwnerFenceSha256,
            Sha256Digest oldOwnerFencedProofSha256) {
        requireState(current, TargetDeleteAuthorityStateV1.DELETE_INTENT_V1);
        TargetDeleteIntentV1 previous = current.deleteIntent().orElseThrow();
        if (previous.dispatchRefresh().isPresent()) {
            throw new IllegalStateException("typed dispatch refresh cannot downgrade to legacy hash-only takeover");
        }
        if (nextDispatchEpoch <= previous.dispatchEpoch()) {
            throw new IllegalArgumentException("dispatch takeover epoch must strictly increase");
        }
        M5TargetDeleteAuthorityRecordsV1.requireDigest(nextDispatchOwnerFenceSha256, "nextDispatchOwnerFenceSha256");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(oldOwnerFencedProofSha256, "oldOwnerFencedProofSha256");
        ExactExternalIdentityV1 external = current.externalIdentity().orElseThrow();
        TargetDeleteIntentV1 successorIntent = new TargetDeleteIntentV1(
                previous.deleteAttemptIdSha256(),
                previous.intentAuthorityRevision(),
                nextDispatchEpoch,
                nextDispatchOwnerFenceSha256,
                Optional.of(oldOwnerFencedProofSha256),
                previous.capabilityDigestSha256(),
                M5TargetDeleteAuthorityKeysV1.dispatchTokenSha256(
                        current.authorityKey(),
                        current.target().targetIdentitySha256(),
                        previous.intentAuthorityRevision(),
                        previous.deleteAttemptIdSha256(),
                        nextDispatchEpoch,
                        nextDispatchOwnerFenceSha256,
                        external.externalIdentitySha256()));
        return M5TargetDeleteAuthorityCodecV1.successor(
                current,
                TargetDeleteAuthorityStateV1.DELETE_INTENT_V1,
                current.closedWriterFenceEpoch(),
                current.proofSnapshotDigest(),
                List.of(),
                current.readFence(),
                current.externalIdentity(),
                Optional.of(successorIntent),
                Optional.empty());
    }

    public static TargetDeleteAuthorityV1 completeDelete(
            TargetDeleteAuthorityV1 current,
            DeleteTerminalOutcomeV1 terminalOutcome,
            Sha256Digest absenceInventoryRootSha256,
            Sha256Digest completionProofDigestSha256) {
        requireState(current, TargetDeleteAuthorityStateV1.DELETE_INTENT_V1);
        Objects.requireNonNull(terminalOutcome, "terminalOutcome");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(absenceInventoryRootSha256, "absenceInventoryRootSha256");
        M5TargetDeleteAuthorityRecordsV1.requireDigest(completionProofDigestSha256, "completionProofDigestSha256");
        ExactExternalIdentityV1 external = current.externalIdentity().orElseThrow();
        if (external.observation() == ExternalIdentityObservationV1.ABSENT_EXACT_V1
                && terminalOutcome != DeleteTerminalOutcomeV1.ALREADY_ABSENT_EXACT_V1) {
            throw new IllegalArgumentException("an initially absent target cannot claim an exact delete outcome");
        }
        TargetDeleteIntentV1 intent = current.deleteIntent().orElseThrow();
        TargetDeleteDoneV1 done = new TargetDeleteDoneV1(
                Sha256Digest.hash(M5TargetDeleteAuthorityCodecV1.encodeAuthority(current)),
                intent.intentAuthorityRevision(),
                intent.deleteAttemptIdSha256(),
                intent.dispatchEpoch(),
                intent.dispatchOwnerFenceSha256(),
                terminalOutcome,
                absenceInventoryRootSha256,
                completionProofDigestSha256);
        return M5TargetDeleteAuthorityCodecV1.successor(
                current,
                TargetDeleteAuthorityStateV1.DELETE_DONE_V1,
                current.closedWriterFenceEpoch(),
                current.proofSnapshotDigest(),
                List.of(),
                current.readFence(),
                current.externalIdentity(),
                current.deleteIntent(),
                Optional.of(done));
    }

    public static void requireExactDispatchAuthority(
            TargetDeleteAuthorityV1 current, Sha256Digest dispatchTokenSha256) {
        requireState(current, TargetDeleteAuthorityStateV1.DELETE_INTENT_V1);
        M5TargetDeleteAuthorityRecordsV1.requireDigest(dispatchTokenSha256, "dispatchTokenSha256");
        if (!current.deleteIntent().orElseThrow().dispatchTokenSha256().equals(dispatchTokenSha256)) {
            throw new IllegalArgumentException("dispatch token differs from the exact current intent");
        }
    }

    private static TargetDeleteAuthorityV1 openSuccessor(
            TargetDeleteAuthorityV1 current, Sha256Digest proofSnapshotDigest, List<ProofBoundWriterTicketV1> tickets) {
        return M5TargetDeleteAuthorityCodecV1.successor(
                current,
                TargetDeleteAuthorityStateV1.OPEN_V1,
                0,
                proofSnapshotDigest,
                tickets,
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty());
    }

    private static void requireOpen(TargetDeleteAuthorityV1 current) {
        requireState(current, TargetDeleteAuthorityStateV1.OPEN_V1);
    }

    private static void requireState(TargetDeleteAuthorityV1 current, TargetDeleteAuthorityStateV1 expected) {
        Objects.requireNonNull(current, "current");
        if (current.state() != expected) {
            throw new IllegalStateException("target authority is not " + expected);
        }
        M5TargetDeleteAuthorityCodecV1.encodeAuthority(current);
    }

    private static Sha256Digest zeroDigest() {
        return Sha256Digest.copyOf(new byte[Sha256Digest.LENGTH]);
    }
}
